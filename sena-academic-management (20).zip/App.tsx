import React, { useState } from 'react';
import { InstructorView } from './components/instructor/InstructorView';
import { ApprenticeView } from './components/apprentice/ApprenticeView';
import { Apprentice, Ficha, FichaDocument, GuideSubmission, Announcement } from './types';
import { MOCK_COMPETENCIES, MOCK_FICHAS } from './constants';

const App: React.FC = () => {
  const [currentView, setCurrentView] = useState<'instructor' | 'apprentice'>('instructor');
  const [viewerRole, setViewerRole] = useState<'instructor' | 'apprentice'>('instructor'); // New state for role context
  const [selectedApprentice, setSelectedApprentice] = useState<Apprentice | null>(null);
  
  // State for managing multiple Fichas
  const [fichas, setFichas] = useState<Ficha[]>(MOCK_FICHAS);
  const [currentFichaId, setCurrentFichaId] = useState<string>(MOCK_FICHAS[0].id);

  // State for Announcements (Novedades)
  const [announcements, setAnnouncements] = useState<Announcement[]>([
    { id: '1', title: 'Reunión de Padres', description: 'Próximo viernes 2:00 PM - Auditorio', type: 'INFO', date: '2024-05-20' },
    { id: '2', title: 'Entrega Pendiente', description: 'Guía 2 de SQL vence mañana.', type: 'ALERT', date: '2024-05-21' }
  ]);

  const currentFicha = fichas.find(f => f.id === currentFichaId) || fichas[0];

  // Modified to accept role (Simulate vs Review)
  const handleSelectApprentice = (apprentice: Apprentice, role: 'instructor' | 'apprentice' = 'instructor') => {
    setSelectedApprentice(apprentice);
    setViewerRole(role);
    setCurrentView('apprentice');
  };

  const handleBack = () => {
    setCurrentView('instructor');
    setSelectedApprentice(null);
    setViewerRole('instructor');
  };

  const handleUpdateApprentices = (fichaId: string, list: Apprentice[]) => {
    setFichas(prevFichas => 
      prevFichas.map(f => f.id === fichaId ? { ...f, apprentices: list } : f)
    );
  };

  const handleAddDocument = (fichaId: string, doc: FichaDocument) => {
    setFichas(prevFichas =>
        prevFichas.map(f => f.id === fichaId ? { ...f, documents: [doc, ...f.documents] } : f)
    );
  };

  const handleSelectFicha = (id: string) => {
    setCurrentFichaId(id);
  };

  const handleCreateFicha = (number: string, program: string) => {
    const newFicha: Ficha = {
      id: Date.now().toString(),
      number,
      program,
      apprentices: [],
      documents: []
    };
    setFichas(prev => [...prev, newFicha]);
    setCurrentFichaId(newFicha.id);
  };

  const handleAddAnnouncement = (announcement: Announcement) => {
    setAnnouncements(prev => [announcement, ...prev]);
  };

  const handleDeleteAnnouncement = (id: string) => {
    setAnnouncements(prev => prev.filter(a => a.id !== id));
  };

  // Logic to save submission from Apprentice OR Instructor
  const handleSaveSubmission = (submission: GuideSubmission) => {
    if (!selectedApprentice) return;

    setFichas(prevFichas => prevFichas.map(f => {
      if (f.id === currentFichaId) {
        return {
          ...f,
          apprentices: f.apprentices.map(a => {
            if (a.id === selectedApprentice.id) {
               const existingSubmissions = a.submissions || [];
               // Update existing submission if guideId matches
               const index = existingSubmissions.findIndex(s => s.guideId === submission.guideId);
               let newSubmissions = [...existingSubmissions];
               
               if (index >= 0) {
                   // Merge to keep instructor signature if we are just updating data, 
                   // or overwrite if this is a fresh save. 
                   // In this case, we replace the object entirely with the incoming one.
                   newSubmissions[index] = submission;
               } else {
                   newSubmissions.push(submission);
               }
               return { ...a, submissions: newSubmissions };
            }
            return a;
          })
        };
      }
      return f;
    }));

    // Update Local Selected Apprentice State
    setSelectedApprentice(prev => {
        if (!prev) return null;
        const existingSubmissions = prev.submissions || [];
        const index = existingSubmissions.findIndex(s => s.guideId === submission.guideId);
        let newSubmissions = [...existingSubmissions];
        if (index >= 0) {
            newSubmissions[index] = submission;
        } else {
            newSubmissions.push(submission);
        }
        return { ...prev, submissions: newSubmissions };
    });
  };

  if (currentView === 'apprentice' && selectedApprentice) {
    return (
      <ApprenticeView 
        apprentice={selectedApprentice} 
        competencies={MOCK_COMPETENCIES} 
        documents={currentFicha.documents}
        onBack={handleBack}
        onSaveSubmission={handleSaveSubmission}
        isInstructorMode={viewerRole === 'instructor'} // Pass the mode
        announcements={announcements}
      />
    );
  }

  return (
    <InstructorView 
      fichas={fichas}
      currentFicha={currentFicha}
      onSelectFicha={handleSelectFicha}
      onCreateFicha={handleCreateFicha}
      onSelectApprentice={handleSelectApprentice} 
      onUpdateApprentices={handleUpdateApprentices}
      onAddDocument={handleAddDocument}
      announcements={announcements}
      onAddAnnouncement={handleAddAnnouncement}
      onDeleteAnnouncement={handleDeleteAnnouncement}
    />
  );
};

export default App;
import React, { useState } from 'react';
import { Competency } from '../../types';

interface Props {
  competency: Competency;
}

export const CompetencyAccordion: React.FC<Props> = ({ competency }) => {
  const [isOpen, setIsOpen] = useState(!competency.isLocked);

  if (competency.isLocked) {
    return (
        <div className="bg-white border border-slate-200 rounded-2xl overflow-hidden shadow-sm opacity-60">
        <button className="w-full px-6 py-5 flex items-center justify-between cursor-not-allowed">
          <div className="flex items-center gap-4">
            <div className="size-10 rounded-xl bg-slate-100 flex items-center justify-center text-slate-400 font-bold text-sm">{competency.number}</div>
            <div className="text-left">
              <h4 className="font-bold text-slate-400">{competency.title}</h4>
              <p className="text-xs text-slate-400 italic">Competencia Transversal</p>
            </div>
          </div>
          <span className="material-symbols-outlined text-slate-300">lock</span>
        </button>
      </div>
    );
  }

  return (
    <div className="bg-white border border-slate-200 rounded-2xl overflow-hidden shadow-sm">
      <button 
        onClick={() => setIsOpen(!isOpen)}
        className="w-full px-6 py-5 flex items-center justify-between hover:bg-slate-50 transition-colors group"
      >
        <div className="flex items-center gap-4">
          <div className="size-10 rounded-xl bg-sena-green/10 flex items-center justify-center text-sena-green font-bold">{competency.number}</div>
          <div className="text-left">
            <h4 className="font-bold text-slate-800 group-hover:text-sena-green transition-colors">{competency.title}</h4>
            <p className="text-xs text-slate-500">{competency.resultsCount} Resultados de Aprendizaje</p>
          </div>
        </div>
        <span className={`material-symbols-outlined text-slate-400 group-hover:text-sena-green transition-transform duration-300 ${isOpen ? 'rotate-180' : ''}`}>expand_more</span>
      </button>
      
      {isOpen && (
        <div className="px-6 pb-6 pt-2 space-y-3">
          {competency.results.map((result) => (
             <div key={result.id} className={`flex items-center justify-between p-4 bg-slate-50 rounded-xl border-l-4 ${result.status === 'APROBADO' ? 'border-sena-green' : 'border-slate-300'}`}>
             <p className="text-sm font-medium text-slate-700">{result.code}: {result.description}</p>
             <span className={`px-3 py-1 text-white text-[10px] font-black rounded-full uppercase tracking-wider ${result.status === 'APROBADO' ? 'bg-sena-green' : 'bg-slate-300 text-slate-600'}`}>
                {result.status}
             </span>
           </div>
          ))}
        </div>
      )}
    </div>
  );
};
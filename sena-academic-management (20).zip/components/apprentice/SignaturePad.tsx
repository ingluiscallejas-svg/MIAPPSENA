import React, { useRef, useState, useEffect } from 'react';

interface SignaturePadProps {
  onSave: (signatureData: string) => void;
  onClear: () => void;
  existingSignature?: string;
}

type SignatureMode = 'DRAW' | 'UPLOAD';

export const SignaturePad: React.FC<SignaturePadProps> = ({ onSave, onClear, existingSignature }) => {
  const [mode, setMode] = useState<SignatureMode>('DRAW');
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [isDrawing, setIsDrawing] = useState(false);
  const [isEmpty, setIsEmpty] = useState(!existingSignature);
  const [previewUrl, setPreviewUrl] = useState<string | null>(existingSignature || null);

  useEffect(() => {
    if (mode === 'DRAW') {
        const canvas = canvasRef.current;
        if (canvas) {
            const ctx = canvas.getContext('2d');
            if (ctx) {
                ctx.lineWidth = 2;
                ctx.lineCap = 'round';
                ctx.strokeStyle = '#000000';
                
                // If there is a preview URL and we are in draw mode, try to draw it on canvas
                // only if it looks like a drawing (transparent/png). 
                // For simplicity, we just clear canvas if switching modes unless we implement full restoration.
                if (previewUrl && !isEmpty) {
                   const img = new Image();
                   img.onload = () => ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
                   img.src = previewUrl;
                }
            }
        }
    }
  }, [mode, previewUrl, isEmpty]);

  const startDrawing = (e: React.MouseEvent<HTMLCanvasElement> | React.TouchEvent<HTMLCanvasElement>) => {
    setIsDrawing(true);
    const canvas = canvasRef.current;
    if (canvas) {
      const ctx = canvas.getContext('2d');
      if (ctx) {
        const { offsetX, offsetY } = getCoordinates(e, canvas);
        ctx.beginPath();
        ctx.moveTo(offsetX, offsetY);
      }
    }
  };

  const draw = (e: React.MouseEvent<HTMLCanvasElement> | React.TouchEvent<HTMLCanvasElement>) => {
    if (!isDrawing) return;
    const canvas = canvasRef.current;
    if (canvas) {
      const ctx = canvas.getContext('2d');
      if (ctx) {
        const { offsetX, offsetY } = getCoordinates(e, canvas);
        ctx.lineTo(offsetX, offsetY);
        ctx.stroke();
        setIsEmpty(false);
      }
    }
  };

  const stopDrawing = () => {
    if (isDrawing) {
        setIsDrawing(false);
        saveCanvas();
    }
  };

  const saveCanvas = () => {
      const canvas = canvasRef.current;
      if (canvas && !isEmpty) {
          const dataUrl = canvas.toDataURL();
          setPreviewUrl(dataUrl);
          onSave(dataUrl);
      }
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
      const file = e.target.files?.[0];
      if (file) {
          const reader = new FileReader();
          reader.onload = (ev) => {
              const result = ev.target?.result as string;
              setPreviewUrl(result);
              setIsEmpty(false);
              onSave(result);
          };
          reader.readAsDataURL(file);
      }
  };

  const clearSignature = () => {
    if (mode === 'DRAW') {
        const canvas = canvasRef.current;
        if (canvas) {
            const ctx = canvas.getContext('2d');
            if (ctx) {
                ctx.clearRect(0, 0, canvas.width, canvas.height);
            }
        }
    }
    setPreviewUrl(null);
    setIsEmpty(true);
    if (fileInputRef.current) fileInputRef.current.value = '';
    onClear();
  };

  const getCoordinates = (e: React.MouseEvent | React.TouchEvent, canvas: HTMLCanvasElement) => {
    let clientX, clientY;
    if ('touches' in e) {
      clientX = e.touches[0].clientX;
      clientY = e.touches[0].clientY;
    } else {
      clientX = (e as React.MouseEvent).clientX;
      clientY = (e as React.MouseEvent).clientY;
    }
    const rect = canvas.getBoundingClientRect();
    return {
      offsetX: clientX - rect.left,
      offsetY: clientY - rect.top
    };
  };

  return (
    <div className="flex flex-col items-center w-full max-w-lg">
      <div className="flex gap-2 mb-4 bg-slate-100 p-1 rounded-lg">
          <button 
            onClick={() => setMode('DRAW')}
            className={`px-4 py-2 text-xs font-bold rounded-md transition-all flex items-center gap-2 ${mode === 'DRAW' ? 'bg-white shadow-sm text-sena-dark' : 'text-slate-500 hover:text-slate-700'}`}
          >
            <span className="material-symbols-outlined text-sm">draw</span>
            Mano Alzada
          </button>
          <button 
            onClick={() => setMode('UPLOAD')}
            className={`px-4 py-2 text-xs font-bold rounded-md transition-all flex items-center gap-2 ${mode === 'UPLOAD' ? 'bg-white shadow-sm text-sena-dark' : 'text-slate-500 hover:text-slate-700'}`}
          >
            <span className="material-symbols-outlined text-sm">image</span>
            Subir Foto/Archivo
          </button>
      </div>

      <div className="w-full">
        {mode === 'DRAW' ? (
            <div className="border-2 border-dashed border-slate-300 rounded-xl bg-white cursor-crosshair relative overflow-hidden group touch-none h-48">
                <canvas
                ref={canvasRef}
                width={500}
                height={192}
                className="w-full h-full object-contain"
                onMouseDown={startDrawing}
                onMouseMove={draw}
                onMouseUp={stopDrawing}
                onMouseLeave={stopDrawing}
                onTouchStart={startDrawing}
                onTouchMove={draw}
                onTouchEnd={stopDrawing}
                />
                {!previewUrl && isEmpty && (
                    <div className="absolute inset-0 flex items-center justify-center pointer-events-none text-slate-200 font-bold text-xl uppercase tracking-widest">
                        Firmar Aquí
                    </div>
                )}
            </div>
        ) : (
            <div 
                onClick={() => fileInputRef.current?.click()}
                className="border-2 border-dashed border-slate-300 rounded-xl bg-slate-50 h-48 flex flex-col items-center justify-center cursor-pointer hover:bg-slate-100 transition-colors relative overflow-hidden"
            >
                <input 
                    ref={fileInputRef}
                    type="file" 
                    accept="image/*,.pdf" // Accepting images for now as they render best, user said 'File' but signature usually image
                    className="hidden"
                    onChange={handleFileUpload}
                />
                {previewUrl ? (
                    <img src={previewUrl} alt="Firma subida" className="h-full w-full object-contain p-2" />
                ) : (
                    <>
                        <span className="material-symbols-outlined text-4xl text-slate-400 mb-2">upload_file</span>
                        <p className="text-sm font-bold text-slate-500">Click para subir foto o archivo de firma</p>
                    </>
                )}
            </div>
        )}
      </div>

      <div className="flex justify-between w-full mt-3 px-1">
        <p className="text-[10px] text-slate-400 font-bold uppercase">
            {mode === 'DRAW' ? 'Use su mouse o dedo para firmar' : 'Formatos: JPG, PNG'}
        </p>
        <button 
            onClick={clearSignature} 
            className="text-xs font-bold text-red-500 hover:text-red-600 flex items-center gap-1"
        >
            <span className="material-symbols-outlined text-sm">delete</span>
            Limpiar
        </button>
      </div>
    </div>
  );
};
import React, { useState, useEffect, useRef } from 'react';
import { FichaDocument, GuideSection, GuideResponse, EvaluationItem, Apprentice, GuideSubmission } from '../../types';
import { STANDARD_SENA_GUIDE_STRUCTURE } from '../../constants';
import { SignaturePad } from './SignaturePad';
import html2canvas from 'html2canvas';
import jsPDF from 'jspdf';

interface GuideViewerProps {
  document: FichaDocument;
  fichaNumber: string;
  apprentice: Apprentice;
  onBack: () => void;
  onSubmit: (submission: GuideSubmission) => void;
  initialSubmission?: GuideSubmission;
  isInstructorMode?: boolean; // New Prop
}

export const GuideViewer: React.FC<GuideViewerProps> = ({ 
  document: fichaDocument, 
  fichaNumber, 
  apprentice, 
  onBack,
  onSubmit,
  initialSubmission,
  isInstructorMode = false
}) => {
  const [responses, setResponses] = useState<Record<string, GuideResponse>>({});
  const [signature, setSignature] = useState<string | null>(null); // Apprentice Signature
  const [instructorSignature, setInstructorSignature] = useState<string | null>(null); // Instructor Signature
  const [isSigned, setIsSigned] = useState(false); // Apprentice signed
  const [isApproved, setIsApproved] = useState(false); // Instructor signed
  const [isGeneratingPdf, setIsGeneratingPdf] = useState(false);
  const [sections, setSections] = useState<GuideSection[]>([]);
  
  // State for LDC grades (checkboxes)
  const [ldcGrades, setLdcGrades] = useState<Record<string, 'CUMPLE' | 'NO_CUMPLE'>>({});
  const [ldcObservations, setLdcObservations] = useState<Record<string, string>>({});
  
  // Ref for the content we want to print (The Hidden Professional Template)
  const printRef = useRef<HTMLDivElement>(null);

  // Load Initial Submission if exists
  useEffect(() => {
    if (initialSubmission) {
        // Guide/PTC Responses
        const responseMap: Record<string, GuideResponse> = {};
        initialSubmission.responses.forEach(r => {
            responseMap[r.sectionId] = r;
        });
        setResponses(responseMap);

        // LDC Responses
        if (initialSubmission.checklistGrades) setLdcGrades(initialSubmission.checklistGrades);
        if (initialSubmission.checklistObservations) setLdcObservations(initialSubmission.checklistObservations);

        setSignature(initialSubmission.signature || null);
        if (initialSubmission.status === 'SUBMITTED' || initialSubmission.status === 'APPROVED') {
            setIsSigned(true);
        }
        
        // Load instructor signature
        if (initialSubmission.instructorSignature) {
            setInstructorSignature(initialSubmission.instructorSignature);
            setIsApproved(true);
        }
    }
  }, [initialSubmission]);

  // Parse instructor structured content into sections (Only for Guides)
  useEffect(() => {
    if (fichaDocument.type === 'GUIA' && fichaDocument.guideContent) {
        const gc = fichaDocument.guideContent;
        const newSections: GuideSection[] = [
            { id: '3.1', title: '3.1 Actividades de Reflexión Inicial', content: gc.reflection, imageUrl: gc.reflectionImage, isActivity: true },
            { id: '3.2', title: '3.2 Actividades de Contextualización', content: gc.contextualization, isActivity: true },
            { id: '3.3', title: '3.3 Actividades de Apropiación', content: gc.appropriation, isActivity: true },
            { id: '3.4', title: '3.4 Actividades de Transferencia', content: gc.transfer, isActivity: true },
            { id: '4', title: '4. Actividades de Evaluación', content: '', isActivity: true, evaluationGrid: gc.evaluations }
        ];
        setSections(newSections);
    } else if (fichaDocument.type === 'GUIA') {
        setSections(STANDARD_SENA_GUIDE_STRUCTURE);
    }
  }, [fichaDocument.guideContent, fichaDocument.type]);

  const handleTextChange = (sectionId: string, text: string) => {
    if (isSigned || isInstructorMode) return;
    setResponses(prev => ({
      ...prev,
      [sectionId]: {
        sectionId,
        textResponse: text,
        imageUrls: prev[sectionId]?.imageUrls || []
      }
    }));
  };

  // Watermark Logic
  const addWatermark = (file: File): Promise<string> => {
    return new Promise((resolve) => {
      const reader = new FileReader();
      reader.onload = (e) => {
        const img = new Image();
        img.onload = () => {
            const canvas = document.createElement('canvas');
            const ctx = canvas.getContext('2d');
            canvas.width = img.width;
            canvas.height = img.height;
            if (ctx) {
                ctx.drawImage(img, 0, 0);
                const fontSize = Math.max(20, img.width * 0.03); 
                ctx.font = `bold ${fontSize}px sans-serif`;
                const text = `${new Date().toLocaleDateString()} - Ficha: ${fichaNumber}`;
                const textWidth = ctx.measureText(text).width;
                const padding = 10;
                ctx.fillStyle = 'rgba(0, 0, 0, 0.5)';
                ctx.fillRect(canvas.width - textWidth - (padding * 2), canvas.height - fontSize - (padding * 2), textWidth + (padding * 2), fontSize + (padding * 2));
                ctx.fillStyle = 'white';
                ctx.fillText(text, canvas.width - textWidth - padding, canvas.height - padding - (fontSize * 0.2));
                resolve(canvas.toDataURL('image/jpeg', 0.8));
            } else {
                resolve(e.target?.result as string);
            }
        };
        img.src = e.target?.result as string;
      };
      reader.readAsDataURL(file);
    });
  };

  const handleFileUpload = async (sectionId: string, file: File) => {
    if (!file || isSigned || isInstructorMode) return;
    const fileUrl = await addWatermark(file);
    setResponses(prev => ({
      ...prev,
      [sectionId]: {
        sectionId,
        textResponse: prev[sectionId]?.textResponse || '',
        imageUrls: [...(prev[sectionId]?.imageUrls || []), fileUrl]
      }
    }));
  };

  const handleRemoveFile = (sectionId: string, index: number) => {
    if (isSigned || isInstructorMode) return;
    setResponses(prev => ({
      ...prev,
      [sectionId]: {
        ...prev[sectionId],
        imageUrls: prev[sectionId].imageUrls.filter((_, i) => i !== index)
      }
    }));
  };

  const handleSaveSignature = (data: string) => {
      if (isSigned && !isInstructorMode) return; 
      if (isInstructorMode && isApproved) return; 

      if (isInstructorMode) {
          setInstructorSignature(data);
      } else {
          setSignature(data);
      }
  };

  const toggleLdcGrade = (itemId: string, type: 'CUMPLE' | 'NO_CUMPLE') => {
      // In Instructor Mode, or if apprentice is filling self-check (if allowed), update state
      // Assuming Instructor does the grading mainly.
      if (!isInstructorMode && isSigned) return; // Locked for apprentice after sign
      setLdcGrades(prev => ({...prev, [itemId]: type}));
  };

  const handleLdcObservation = (itemId: string, text: string) => {
      setLdcObservations(prev => ({...prev, [itemId]: text}));
  };

  const handleSubmit = () => {
    if (!signature && !isInstructorMode) {
        alert("Debes firmar el documento antes de finalizar.");
        return;
    }
    if (isInstructorMode) {
        if (!instructorSignature) {
            alert("Debes firmar para aprobar el documento.");
            return;
        }
        const submission: GuideSubmission = {
            guideId: fichaDocument.id,
            responses: Object.values(responses),
            signature: signature || '',
            signedAt: initialSubmission?.signedAt,
            status: 'APPROVED',
            instructorSignature: instructorSignature,
            instructorSignedAt: new Date().toISOString(),
            checklistGrades: ldcGrades, // Save LDC specific
            checklistObservations: ldcObservations
        };
        setIsApproved(true);
        onSubmit(submission);
        alert("Documento aprobado y firmado por el instructor.");
    } else {
        const submission: GuideSubmission = {
            guideId: fichaDocument.id,
            responses: Object.values(responses),
            signature: signature || '',
            signedAt: new Date().toISOString(),
            status: 'SUBMITTED',
            checklistGrades: ldcGrades,
            checklistObservations: ldcObservations
        };
        setIsSigned(true);
        onSubmit(submission);
        const msg = document.createElement('div');
        msg.className = "fixed top-10 left-1/2 transform -translate-x-1/2 bg-sena-green text-white px-8 py-6 rounded-2xl shadow-2xl z-50 text-center animate-[fadeIn_0.5s_ease-out]";
        msg.innerHTML = `
            <span class="material-symbols-outlined text-4xl mb-2">sentiment_satisfied</span>
            <h3 class="text-xl font-bold">¡Gracias por realizar ${fichaDocument.title}!</h3>
            <p class="mt-2 text-sm font-medium">Documento enviado al instructor.</p>
        `;
        document.body.appendChild(msg);
        setTimeout(() => {
            msg.style.opacity = '0';
            setTimeout(() => document.body.removeChild(msg), 500);
        }, 4000);
    }
  };

  const handleDownloadPDF = async () => {
    if (!printRef.current) return;
    
    setIsGeneratingPdf(true);
    try {
        // Setup PDF
        const pdf = new jsPDF('p', 'mm', 'a4');
        const pdfWidth = pdf.internal.pageSize.getWidth();
        const pdfHeight = pdf.internal.pageSize.getHeight();
        const margin = 15; // mm
        const contentWidth = pdfWidth - (margin * 2);
        
        let currentY = margin;

        // Find all "print-item" elements. These are the blocks we don't want to cut.
        const elements = printRef.current.querySelectorAll('.print-item');
        
        // Wait for images to load (just in case)
        await new Promise(r => setTimeout(r, 500));

        for (let i = 0; i < elements.length; i++) {
            const el = elements[i] as HTMLElement;
            
            // Convert specific element to canvas
            const canvas = await html2canvas(el, {
                scale: 2, 
                useCORS: true, 
                logging: false,
                backgroundColor: '#ffffff'
            });

            const imgData = canvas.toDataURL('image/jpeg', 1.0);
            
            // Calculate height in PDF units
            const imgHeight = (canvas.height * contentWidth) / canvas.width;

            // Check if we need a page break
            if (currentY + imgHeight > pdfHeight - margin) {
                pdf.addPage();
                currentY = margin;
            }

            // Add image
            pdf.addImage(imgData, 'JPEG', margin, currentY, contentWidth, imgHeight);
            
            // Move cursor
            currentY += imgHeight + 5; // 5mm padding between blocks
        }

        const safeTitle = fichaDocument.title.replace(/[^a-zA-Z0-9]/g, '_');
        const fileName = `${safeTitle}_${apprentice.fullName.replace(/\s+/g, '_')}.pdf`;
        pdf.save(fileName);

    } catch (error) {
        console.error("PDF Generation failed", error);
        alert("Error al generar el PDF. Por favor intente nuevamente.");
    } finally {
        setIsGeneratingPdf(false);
    }
  };

  // --- STANDARD RENDER FOR INTERACTIVE VIEW ---
  const renderSection = (section: GuideSection) => {
    const response = responses[section.id];
    
    // SECTION 4: EVALUATION GRID
    if (section.id === '4' && section.evaluationGrid) {
        return (
            <div key={section.id} className="mb-10 scroll-mt-24 break-inside-avoid" id={`section-${section.id}`}>
                <h3 className="text-lg font-extrabold text-sena-dark mb-4 border-b border-slate-200 pb-2">{section.title}</h3>
                <div className="rounded-xl border border-slate-200 shadow-sm overflow-hidden">
                    <table className="w-full text-left text-sm table-fixed">
                        <thead>
                            <tr className="bg-sena-dark text-white">
                                <th className="p-4 w-[35%] font-bold border-r border-slate-600 uppercase text-xs tracking-wider">Evidencias</th>
                                <th className="p-4 w-[35%] font-bold border-r border-slate-600 uppercase text-xs tracking-wider">Criterios</th>
                                <th className="p-4 w-[30%] font-bold uppercase text-xs tracking-wider">Evaluación</th>
                            </tr>
                        </thead>
                        <tbody className="divide-y divide-slate-200 bg-white">
                            {section.evaluationGrid.map((item, idx) => {
                                const rowId = `eval-${idx}`;
                                const rowResponse = responses[rowId];
                                return (
                                    <tr key={idx} className="hover:bg-slate-50 break-inside-avoid">
                                        <td className="p-4 align-top border-r border-slate-100">
                                            <p className="font-bold text-slate-800 mb-3 whitespace-pre-wrap text-xs">{item.evidence}</p>
                                            <div className="mt-2 pt-2 border-t border-slate-100">
                                                <div className="space-y-2 mb-2">
                                                    {rowResponse?.imageUrls.map((url, i) => (
                                                        <div key={i} className="flex items-center gap-2 bg-slate-100 p-2 rounded text-xs">
                                                            <span className="material-symbols-outlined text-slate-500 text-sm">image</span>
                                                            <span className="flex-1 truncate text-slate-600">Evidencia {i + 1}</span>
                                                            {!isSigned && !isInstructorMode && (
                                                                <button onClick={() => handleRemoveFile(rowId, i)} className="text-red-500 hover:text-red-700"><span className="material-symbols-outlined text-sm">close</span></button>
                                                            )}
                                                        </div>
                                                    ))}
                                                </div>
                                                {!isSigned && !isInstructorMode && (
                                                    <label className="inline-flex items-center gap-2 px-3 py-1.5 bg-sena-green text-white text-[10px] font-bold rounded-lg cursor-pointer hover:bg-[#2e8600] transition-colors">
                                                        <span className="material-symbols-outlined text-sm">add_a_photo</span> 
                                                        Adjuntar Evidencia
                                                        <input type="file" accept="image/*" capture="environment" className="hidden" onChange={(e) => e.target.files && handleFileUpload(rowId, e.target.files[0])} />
                                                    </label>
                                                )}
                                            </div>
                                        </td>
                                        <td className="p-4 align-top border-r border-slate-100 text-slate-600 bg-slate-50/50">
                                            <p className="whitespace-pre-wrap leading-relaxed text-xs">{item.criteria}</p>
                                        </td>
                                        <td className="p-4 align-top text-slate-600 bg-slate-50/50">
                                            <div className="space-y-3">
                                                <div><span className="block text-[10px] font-bold text-sena-green uppercase">Técnica</span><p className="text-xs">{item.technique}</p></div>
                                                <div className="border-t border-slate-200 pt-2"><span className="block text-[10px] font-bold text-sena-green uppercase">Instrumento</span><p className="text-xs">{item.instrument}</p></div>
                                            </div>
                                        </td>
                                    </tr>
                                );
                            })}
                        </tbody>
                    </table>
                </div>
            </div>
        );
    }
    
    if (!section.content && !section.imageUrl) return null;
    return (
      <div key={section.id} className="mb-10 scroll-mt-24 break-inside-avoid" id={`section-${section.id}`}>
        <h3 className="text-lg font-extrabold text-sena-dark mb-4 border-b border-slate-200 pb-2">{section.title}</h3>
        <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm mb-6">
            <p className="text-slate-700 whitespace-pre-wrap leading-relaxed text-sm font-medium">{section.content}</p>
            {section.imageUrl && (<div className="mt-4 rounded-lg overflow-hidden border border-slate-100 max-w-md"><img src={section.imageUrl} alt="Imagen de apoyo" className="w-full h-auto" /></div>)}
        </div>
        {section.isActivity && (
          <div className="bg-slate-50 border-2 border-slate-200 border-dashed rounded-xl p-6 relative overflow-hidden break-inside-avoid">
            <div className="mb-4 relative z-10">
              <label className="block text-xs font-bold text-sena-green uppercase mb-2">Tu Respuesta / Desarrollo:</label>
              {isSigned || isInstructorMode ? (
                   <div className="w-full p-4 bg-white border border-slate-200 rounded-lg text-sm text-slate-800 whitespace-pre-wrap min-h-[100px]">{response?.textResponse || 'Sin respuesta.'}</div>
              ) : (
                  <textarea value={response?.textResponse || ''} onChange={(e) => handleTextChange(section.id, e.target.value)} placeholder={`Escribe aquí...`} className="w-full h-40 p-3 text-sm bg-white border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-sena-green/30 resize-y shadow-sm" />
              )}
            </div>
            
            <div className="relative z-10 mt-6 border-t border-slate-200 pt-4">
                 <label className="block text-xs font-bold text-slate-500 uppercase mb-3">Evidencias Fotográficas</label>
                 <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                    {response?.imageUrls.map((url, i) => (
                        <div key={i} className="relative group aspect-square rounded-lg overflow-hidden border border-slate-300 bg-white shadow-sm">
                            <img src={url} alt={`Evidencia ${i}`} className="w-full h-full object-cover" />
                            {!isSigned && !isInstructorMode && (
                                <button onClick={() => handleRemoveFile(section.id, i)} className="absolute top-1 right-1 bg-red-500 text-white rounded-full p-1 opacity-0 group-hover:opacity-100 transition-opacity"><span className="material-symbols-outlined text-xs block">close</span></button>
                            )}
                        </div>
                    ))}
                    {!isSigned && !isInstructorMode && (
                        <label className="border-2 border-dashed border-slate-300 rounded-lg flex flex-col items-center justify-center cursor-pointer hover:border-sena-green hover:bg-sena-green/5 transition-colors aspect-square">
                            <input type="file" accept="image/*" capture="environment" className="hidden" onChange={(e) => e.target.files && handleFileUpload(section.id, e.target.files[0])} />
                            <span className="material-symbols-outlined text-3xl text-slate-400 mb-1">add_a_photo</span>
                            <span className="text-[10px] font-bold text-slate-500 text-center">Cámara / Archivo</span>
                        </label>
                    )}
                 </div>
            </div>
          </div>
        )}
      </div>
    );
  };

  const renderChecklist = () => {
    if (!fichaDocument.checklistContent) return null;
    const ldc = fichaDocument.checklistContent;
    
    return (
        <div className="print-item bg-white">
            {/* Header (Logo & Regional) */}
            <div className="border border-slate-300 mb-6">
                <div className="flex flex-col items-center justify-center p-4 border-b border-slate-300">
                    <img src="https://www.sena.edu.co/Style%20Library/alayout/images/logoSena.png" alt="SENA" className="w-16 mb-2" />
                    <h2 className="font-bold uppercase text-center text-sm">Regional Norte de Santander</h2>
                    <h3 className="text-xs text-center font-bold">Centro de Formación para el Desarrollo Rural y Minero</h3>
                    <h1 className="text-lg font-bold mt-2 uppercase tracking-wide">Lista de Chequeo</h1>
                </div>
                
                {/* I. General Info */}
                <div className="p-0 text-xs">
                    <div className="bg-slate-100 font-bold p-1 pl-2 border-b border-slate-300">I. INFORMACIÓN GENERAL:</div>
                    <div className="grid grid-cols-[30%_70%] border-b border-slate-300">
                        <div className="bg-slate-50 p-1 pl-2 font-bold border-r border-slate-300 flex items-center">Programa de Formación</div>
                        <div className="bg-white text-black p-1 pl-2 font-medium">{ldc.program}</div>
                    </div>
                    <div className="grid grid-cols-[30%_70%] border-b border-slate-300">
                        <div className="bg-slate-50 p-1 pl-2 font-bold border-r border-slate-300 flex items-center">No de Ficha</div>
                        <div className="bg-white text-black p-1 pl-2 font-medium">{fichaNumber}</div>
                    </div>
                    <div className="grid grid-cols-[30%_70%] border-b border-slate-300">
                        <div className="bg-slate-50 p-1 pl-2 font-bold border-r border-slate-300 flex items-center">Competencia Asociada</div>
                        <div className="bg-white p-1 pl-2 font-medium uppercase">{ldc.competency}</div>
                    </div>
                    <div className="grid grid-cols-[30%_70%] border-b border-slate-300">
                        <div className="bg-slate-50 p-1 pl-2 font-bold border-r border-slate-300 flex items-center">Resultados de Aprendizaje a evaluar</div>
                        <div className="bg-white p-1 pl-2 font-medium h-16 flex items-center">{ldc.rap}</div>
                    </div>
                    <div className="grid grid-cols-[30%_70%] border-b border-slate-300">
                        <div className="bg-slate-50 p-1 pl-2 font-bold border-r border-slate-300 flex items-center">Criterios de Evaluación</div>
                        <div className="bg-white p-1 pl-2 font-medium">{ldc.criteria}</div>
                    </div>
                    <div className="grid grid-cols-[30%_70%] border-b border-slate-300">
                        <div className="bg-slate-50 p-1 pl-2 font-bold border-r border-slate-300 flex items-center">Fecha de Aplicación</div>
                        <div className="bg-white p-1 pl-2 font-medium">{new Date().toLocaleDateString()}</div>
                    </div>
                    <div className="grid grid-cols-[30%_70%] border-b border-slate-300">
                        <div className="bg-slate-50 p-1 pl-2 font-bold border-r border-slate-300 flex items-center">Nombre del Instructor</div>
                        <div className="bg-white p-1 pl-2 font-medium uppercase">{ldc.instructorName}</div>
                    </div>
                    <div className="grid grid-cols-[30%_70%] border-b border-slate-300">
                        <div className="bg-slate-50 p-1 pl-2 font-bold border-r border-slate-300 flex items-center">Nombre del Aprendiz</div>
                        <div className="bg-white p-1 pl-2 font-medium uppercase">{apprentice.fullName}</div>
                    </div>
                     <div className="grid grid-cols-[30%_35%_35%] border-b border-slate-300">
                        <div className="bg-slate-50 p-1 pl-2 font-bold border-r border-slate-300 flex items-center">Tipo de Evidencia</div>
                        <div className="p-1 pl-2 font-medium text-center border-r border-slate-300 bg-white">Desempeño ( {ldc.evidenceType === 'DESEMPENO' ? 'X' : ' '} )</div>
                        <div className="p-1 pl-2 font-medium text-center bg-white">Producto ( {ldc.evidenceType === 'PRODUCTO' ? 'X' : ' '} )</div>
                    </div>
                </div>

                {/* II. Evidencia para Evaluar */}
                <div className="p-0 text-xs">
                    <div className="bg-slate-100 font-bold p-1 pl-2 border-b border-slate-300 uppercase">II. EVIDENCIA PARA EVALUAR:</div>
                    <div className="p-6 text-center font-bold text-sm min-h-[100px] flex items-center justify-center border-b border-slate-300 bg-white">
                        {ldc.activityDescription}
                    </div>
                </div>

                {/* III. Items a Evaluar */}
                <div className="p-0 text-xs">
                     <div className="bg-slate-100 font-bold p-1 pl-2 border-b border-slate-300 uppercase">III. ITEMS A EVALUAR</div>
                     <table className="w-full border-collapse border border-slate-400">
                         <thead>
                             <tr className="bg-slate-200">
                                 <th rowSpan={2} className="border border-slate-400 w-10">Items</th>
                                 <th rowSpan={2} className="border border-slate-400">Variables/Indicadores<br/><span className="font-normal">Desempeño</span></th>
                                 <th colSpan={2} className="border border-slate-400 w-24">Cumple</th>
                                 <th rowSpan={2} className="border border-slate-400 w-1/4">OBSERVACIONES</th>
                             </tr>
                             <tr className="bg-slate-200">
                                 <th className="border border-slate-400 w-12">SI</th>
                                 <th className="border border-slate-400 w-12">NO</th>
                             </tr>
                         </thead>
                         <tbody>
                             {ldc.items.map((item, idx) => (
                                 <tr key={item.id} className="bg-white"> 
                                     <td className="border border-slate-400 text-center bg-slate-100 font-bold p-1">{idx + 1}</td>
                                     <td className="border border-slate-400 p-1 font-medium pl-2">{item.text}</td>
                                     <td className="border border-slate-400 text-center align-middle p-1">
                                         <input 
                                            type="checkbox" 
                                            checked={ldcGrades[item.id] === 'CUMPLE'} 
                                            onChange={() => toggleLdcGrade(item.id, 'CUMPLE')}
                                            disabled={!isInstructorMode}
                                            className="h-5 w-5 border-slate-400 rounded accent-black cursor-pointer disabled:opacity-100"
                                         />
                                     </td>
                                     <td className="border border-slate-400 text-center align-middle p-1">
                                          <input 
                                            type="checkbox" 
                                            checked={ldcGrades[item.id] === 'NO_CUMPLE'} 
                                            onChange={() => toggleLdcGrade(item.id, 'NO_CUMPLE')}
                                            disabled={!isInstructorMode}
                                            className="h-5 w-5 border-slate-400 rounded accent-black cursor-pointer disabled:opacity-100"
                                         />
                                     </td>
                                     <td className="border border-slate-400 p-0 bg-white">
                                         <input 
                                            type="text" 
                                            value={ldcObservations[item.id] || ''}
                                            onChange={(e) => handleLdcObservation(item.id, e.target.value)}
                                            className="w-full h-full p-1 border-none outline-none bg-transparent text-black"
                                         />
                                     </td>
                                 </tr>
                             ))}
                         </tbody>
                     </table>
                </div>

                {/* Footer Result */}
                <div className="flex border border-slate-300 mt-2 font-bold text-xs p-2 items-center justify-between">
                    <span>RESULTADO EVIDENCIA:</span>
                    <div className="flex gap-10">
                        <label className="flex items-center gap-2">
                            <span>CUMPLE</span>
                            <div className={`w-4 h-4 border border-black ${Object.values(ldcGrades).every(v => v === 'CUMPLE') && Object.values(ldcGrades).length === ldc.items.length ? 'bg-black' : 'bg-white'}`}></div>
                        </label>
                        <label className="flex items-center gap-2">
                            <span>NO CUMPLE</span>
                            <div className={`w-4 h-4 border border-black ${Object.values(ldcGrades).some(v => v === 'NO_CUMPLE') ? 'bg-black' : 'bg-white'}`}></div>
                        </label>
                    </div>
                </div>

                {/* Signatures */}
                <div className="flex mt-12 gap-10 px-4 mb-8">
                     <div className="w-1/2 border-t border-black pt-1 text-center font-bold text-xs">
                        {instructorSignature && <img src={instructorSignature} className="h-12 mx-auto mb-[-10px] mix-blend-multiply block" alt="Firma Inst" />}
                        Firma del Instructor
                     </div>
                     <div className="w-1/2 border-t border-black pt-1 text-center font-bold text-xs">
                        {signature && <img src={signature} className="h-12 mx-auto mb-[-10px] mix-blend-multiply block" alt="Firma Apr" />}
                        Firma del Aprendiz
                     </div>
                </div>

            </div>
        </div>
    );
  };

  return (
    <div className="bg-slate-100 min-h-screen font-sans pb-20">
      
      {/* --- HIDDEN PRINT TEMPLATE (PROFESSIONAL FORMAT) --- */}
      {/* We apply 'print-item' class to direct children we want to keep together */}
      <div 
        id="print-container-ref"
        ref={printRef} 
        className="absolute top-0 left-0 bg-white z-[-50] text-black font-sans"
        style={{ width: '794px', padding: '40px', boxSizing: 'border-box', opacity: isGeneratingPdf ? 1 : 0 }} 
      >
        {fichaDocument.checklistContent ? (
            // Custom Renderer for LDC Printing
            renderChecklist()
        ) : (
            // Default Guide Printing Logic
            <>
              <div className="print-item mb-6">
                <table className="w-full border-collapse border border-black">
                    <tbody>
                        <tr>
                            <td className="border border-black p-2 w-24 text-center">
                                <img src="https://www.sena.edu.co/Style%20Library/alayout/images/logoSena.png" alt="SENA" className="w-16 mx-auto" />
                            </td>
                            <td className="border border-black p-2 text-center font-bold">
                                <p className="text-sm">SERVICIO NACIONAL DE APRENDIZAJE SENA</p>
                                <p className="text-xs">INSTRUMENTO DE EVALUACIÓN</p>
                                <p className="text-xs">GUÍA DE APRENDIZAJE</p>
                            </td>
                            <td className="border border-black p-2 w-32 text-center text-xs font-bold bg-gray-100">
                                {new Date().toLocaleDateString()}
                            </td>
                        </tr>
                    </tbody>
                </table>
              </div>

              <div className="print-item border border-black mb-6 text-xs">
                  <div className="flex border-b border-black">
                      <div className="w-1/4 bg-gray-100 p-1 font-bold border-r border-black">PROGRAMA:</div>
                      <div className="w-3/4 p-1 uppercase">Análisis y Desarrollo de Software</div>
                  </div>
                  <div className="flex border-b border-black">
                      <div className="w-1/4 bg-gray-100 p-1 font-bold border-r border-black">FICHA:</div>
                      <div className="w-3/4 p-1">{fichaNumber}</div>
                  </div>
                  <div className="flex border-b border-black">
                      <div className="w-1/4 bg-gray-100 p-1 font-bold border-r border-black">APRENDIZ:</div>
                      <div className="w-3/4 p-1 uppercase font-bold">{apprentice.fullName} ({apprentice.documentType} {apprentice.documentNumber})</div>
                  </div>
                  <div className="flex">
                      <div className="w-1/4 bg-gray-100 p-1 font-bold border-r border-black">DOCUMENTO:</div>
                      <div className="w-3/4 p-1 uppercase">{fichaDocument.title}</div>
                  </div>
              </div>

              {sections.map(section => {
                   const response = responses[section.id];
                   
                   if (section.id === '4' && section.evaluationGrid) {
                       return (
                           <div key={section.id} className="print-item mb-6">
                               <div className="bg-sena-dark text-white font-bold p-1 text-sm mb-2 uppercase">{section.title}</div>
                               <table className="w-full border-collapse border border-black text-xs table-fixed">
                                   <thead>
                                       <tr className="bg-gray-200">
                                           <th className="border border-black p-2 w-[40%]">EVIDENCIAS / DESARROLLO</th>
                                           <th className="border border-black p-2 w-[30%]">CRITERIOS</th>
                                           <th className="border border-black p-2 w-[30%]">EVALUACIÓN</th>
                                       </tr>
                                   </thead>
                                   <tbody>
                                       {section.evaluationGrid.map((item, idx) => {
                                            const rowId = `eval-${idx}`;
                                            const rowResponse = responses[rowId];
                                            return (
                                                <tr key={idx}>
                                                    <td className="border border-black p-2 align-top break-words">
                                                        <p className="font-bold mb-2 break-words whitespace-pre-wrap">{item.evidence}</p>
                                                        {rowResponse?.imageUrls && rowResponse.imageUrls.length > 0 && (
                                                            <div className="grid grid-cols-2 gap-2 mt-2">
                                                                {rowResponse.imageUrls.map((url, i) => (
                                                                    <img key={i} src={url} className="w-full h-auto border border-gray-300 block" alt="Evidencia" />
                                                                ))}
                                                            </div>
                                                        )}
                                                    </td>
                                                    <td className="border border-black p-2 align-top text-justify break-words whitespace-pre-wrap">{item.criteria}</td>
                                                    <td className="border border-black p-2 align-top break-words">
                                                        <p><span className="font-bold">Técnica:</span> {item.technique}</p>
                                                        <p><span className="font-bold">Instrumento:</span> {item.instrument}</p>
                                                    </td>
                                                </tr>
                                            )
                                       })}
                                   </tbody>
                               </table>
                           </div>
                       )
                   }

                   if (!section.content && !section.imageUrl) return null;

                   return (
                       <div key={section.id} className="print-item mb-6">
                            <h3 className="font-bold text-sm uppercase mb-2 border-b border-gray-400 pb-1">{section.title}</h3>
                            <p className="text-xs text-justify mb-2 whitespace-pre-wrap break-words">{section.content}</p>
                            
                            {section.isActivity && (
                                <div className="mt-2 border border-gray-300 p-2 bg-gray-50">
                                    <p className="text-[10px] font-bold text-gray-500 uppercase mb-1">Desarrollo del Aprendiz:</p>
                                    <div className="text-xs whitespace-pre-wrap font-mono text-black break-words max-w-full">{response?.textResponse || 'Sin respuesta.'}</div>
                                    
                                    {response?.imageUrls && response.imageUrls.length > 0 && (
                                        <div className="mt-4 pt-2 border-t border-gray-200">
                                            <p className="text-[10px] font-bold text-gray-500 uppercase mb-2">Anexos:</p>
                                            <div className="grid grid-cols-3 gap-2">
                                                {response.imageUrls.map((url, i) => (
                                                    <img key={i} src={url} className="w-full h-auto border border-gray-300" alt="Anexo" />
                                                ))}
                                            </div>
                                        </div>
                                    )}
                                </div>
                            )}
                       </div>
                   )
              })}
              <div className="print-item mt-10 pt-4">
                 <div className="flex justify-between gap-10">
                     <div className="w-1/2 border-t border-black pt-2 text-center">
                         {instructorSignature && <img src={instructorSignature} className="h-16 mx-auto mb-[-20px] mix-blend-multiply" alt="Firma Inst" />}
                         <p className="text-xs font-bold uppercase mt-8">Firma del Instructor</p>
                     </div>
                     <div className="w-1/2 border-t border-black pt-2 text-center">
                         {signature && <img src={signature} className="h-16 mx-auto mb-[-20px] mix-blend-multiply" alt="Firma Apr" />}
                         <p className="text-xs font-bold uppercase mt-8">Firma del Aprendiz</p>
                     </div>
                 </div>
              </div>
            </>
        )}
      </div>

      {/* --- NORMAL INTERACTIVE VIEW --- */}
      <div className="sticky top-0 z-40 bg-white border-b border-slate-200 shadow-sm">
        <div className="max-w-4xl mx-auto px-4 h-16 flex items-center justify-between">
          <button onClick={onBack} className="flex items-center gap-2 text-slate-500 hover:text-sena-dark transition-colors"><span className="material-symbols-outlined">arrow_back</span><span className="text-sm font-bold">Volver</span></button>
          <div className="text-center">
            <h2 className="text-sm font-bold text-sena-dark uppercase truncate max-w-[200px] md:max-w-md">{fichaDocument.title}</h2>
          </div>
          <div className="w-20 flex justify-end">
            <span className={`px-2 py-1 rounded text-[10px] font-bold uppercase ${isApproved ? 'bg-green-100 text-green-700' : isSigned ? 'bg-orange-100 text-orange-700' : 'bg-slate-200 text-slate-500'}`}>
                {isApproved ? 'Aprobado' : isSigned ? 'Pendiente' : 'Borrador'}
            </span>
          </div>
        </div>
      </div>

      <div className="max-w-5xl mx-auto px-6 py-8 bg-slate-100 print:bg-white">
        {fichaDocument.type === 'PTC' && fichaDocument.ptcContent ? (
            // PTC Layout
            <div ref={printRef} className="bg-white border border-gray-400 p-0 text-xs text-black font-sans leading-tight shadow-md">
                <div className="grid grid-cols-12 border-b border-gray-400">
                    <div className="col-span-3 border-r border-gray-400 flex items-center justify-center p-2">
                        <img src="https://www.sena.edu.co/Style%20Library/alayout/images/logoSena.png" alt="SENA" className="h-16 w-auto" />
                    </div>
                    <div className="col-span-6 border-r border-gray-400 flex flex-col items-center justify-center p-2 text-center font-bold">
                        <p>SERVICIO NACIONAL DE APRENDIZAJE SENA</p>
                        <p>PLAN DE TRABAJO CONCERTADO</p>
                    </div>
                    <div className="col-span-3 flex flex-col justify-center items-center p-2 font-bold bg-white">
                        <p>Fecha: {fichaDocument.ptcContent.date}</p>
                    </div>
                </div>
                {/* Simplified PTC View for brevity, assumes existing structure logic */}
                <div className="p-4 text-center text-slate-500 italic">Contenido del PTC (Vista Simplificada para esta demo)</div>
             </div>
        ) : fichaDocument.type === 'LDC' && fichaDocument.checklistContent ? (
            // --- NEW LDC INTERACTIVE VIEW ---
            <div className="bg-white p-2 md:p-8 rounded-xl shadow-lg border border-slate-200">
                {renderChecklist()}
            </div>
        ) : fichaDocument.type === 'GUIA' ? (
             sections.length > 0 ? sections.map(renderSection) : <div className="p-4 text-center">No content</div>
        ) : (
             <div className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden mb-8">
                 {fichaDocument.gridContent && (
                    <div className="overflow-x-auto">
                        <table className="w-full text-left border-collapse text-xs">
                            <thead className="bg-sena-dark text-white">
                                <tr>{fichaDocument.gridContent.headers.map((h, i) => <th key={i} className="px-4 py-3">{h}</th>)}</tr>
                            </thead>
                            <tbody className="divide-y divide-slate-100">
                                {fichaDocument.gridContent.rows.map((row, i) => <tr key={i}>{row.map((cell, j) => <td key={j} className="px-4 py-3 border-r">{cell}</td>)}</tr>)}
                            </tbody>
                        </table>
                    </div>
                 )}
            </div>
        )}

        {/* --- SIGNATURE / ACTION AREA --- */}
        <div className="mt-12 pt-10 border-t border-slate-300 break-inside-avoid print:hidden">
            {isInstructorMode ? (
                isSigned ? (
                    isApproved ? (
                        <div className="text-center p-6 bg-green-50 rounded-xl border border-green-200 shadow-sm">
                            <span className="material-symbols-outlined text-4xl text-sena-green mb-2">verified</span>
                            <h3 className="text-xl font-bold text-sena-green">Documento Concertado y Aprobado</h3>
                            <p className="text-sm text-slate-600">Firma digital registrada.</p>
                        </div>
                    ) : (
                        <div className="flex flex-col items-center animate-[fadeIn_0.5s_ease-out]">
                             <h3 className="text-xl font-bold text-sena-dark mb-2 text-center">Concertación y Aprobación</h3>
                             <p className="text-sm text-slate-500 mb-6 text-center max-w-md">Revise las respuestas y evidencias del aprendiz. Si está de acuerdo, firme para formalizar el documento.</p>
                             <SignaturePad onSave={handleSaveSignature} onClear={() => setInstructorSignature(null)} existingSignature={instructorSignature || undefined} />
                        </div>
                    )
                ) : (
                    <div className="text-center p-6 bg-orange-50 rounded-xl border border-orange-200 shadow-sm">
                        <span className="material-symbols-outlined text-4xl text-orange-500 mb-2">pending</span>
                        <h3 className="text-lg font-bold text-orange-700">Esperando envío del Aprendiz</h3>
                    </div>
                )
            ) : (
                 <>
                    <h3 className="text-xl font-bold text-sena-dark mb-2 text-center">Formalización</h3>
                    <div className="flex justify-center mb-8">
                        {isSigned ? (
                            <div className="text-center p-4 bg-green-50 rounded-xl border border-green-200 shadow-sm">
                                <p className="text-xs text-sena-green font-bold flex items-center justify-center gap-1">
                                    <span className="material-symbols-outlined text-sm">check_circle</span>
                                    Documento Firmado y Enviado
                                </p>
                            </div>
                        ) : (
                            <SignaturePad onSave={handleSaveSignature} onClear={() => setSignature(null)} existingSignature={signature || undefined} />
                        )}
                    </div>
                 </>
            )}
        </div>
      </div>

      <div className="fixed bottom-0 inset-x-0 p-4 bg-white border-t border-slate-200 flex justify-center gap-4 z-50 print:hidden">
            {!isSigned && !isInstructorMode && (
                 <button onClick={handleSubmit} disabled={!signature} className="px-10 py-3 bg-sena-green text-white font-bold rounded-xl hover:bg-[#2e8600] transition-colors shadow-lg shadow-sena-green/20 disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-3">
                    <span className="material-symbols-outlined">verified_user</span> <span>Confirmar y Firmar</span>
                </button>
            )}
            {isInstructorMode && isSigned && !isApproved && (
                 <button onClick={handleSubmit} disabled={!instructorSignature} className="px-10 py-3 bg-sena-dark text-white font-bold rounded-xl hover:bg-slate-800 transition-colors shadow-lg shadow-sena-dark/20 disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-3">
                    <span className="material-symbols-outlined">gavel</span> <span>Aprobar y Firmar</span>
                </button>
            )}
            {(isApproved || (isSigned && !isInstructorMode)) && (
                <button onClick={handleDownloadPDF} disabled={isGeneratingPdf} className="px-10 py-3 bg-blue-600 text-white font-bold rounded-xl hover:bg-blue-700 transition-colors shadow-lg shadow-blue-600/20 flex items-center gap-3 disabled:opacity-70">
                    {isGeneratingPdf ? <><span className="material-symbols-outlined animate-spin">refresh</span><span>Generando PDF...</span></> : <><span className="material-symbols-outlined">download</span><span>Descargar PDF</span></>}
                </button>
            )}
      </div>
    </div>
  );
};
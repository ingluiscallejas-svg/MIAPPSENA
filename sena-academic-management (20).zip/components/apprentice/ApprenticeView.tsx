import React, { useState } from 'react';
import { Apprentice, Competency, FichaDocument, DocumentType, GuideSubmission, Announcement } from '../../types';
import { CompetencyAccordion } from './CompetencyAccordion';
import { GuideViewer } from './GuideViewer';

interface Props {
  apprentice: Apprentice;
  competencies: Competency[];
  documents: FichaDocument[];
  onBack: () => void;
  onSaveSubmission: (submission: GuideSubmission) => void;
  isInstructorMode?: boolean; // New prop
  announcements?: Announcement[]; // New prop for dynamic news
}

type TabType = 'competencias' | 'ptc' | 'ldc' | 'guias';

export const ApprenticeView: React.FC<Props> = ({ 
  apprentice, 
  competencies, 
  documents, 
  onBack, 
  onSaveSubmission, 
  isInstructorMode = false,
  announcements = [] // Default to empty array if not provided
}) => {
  const [activeTab, setActiveTab] = useState<TabType>('competencias');
  const [selectedGuide, setSelectedGuide] = useState<FichaDocument | null>(null);

  const FICHA_NUMBER_DISPLAY = "2503412"; 

  if (selectedGuide) {
    // Find existing submission for this document
    const existingSubmission = apprentice.submissions?.find(s => s.guideId === selectedGuide.id);

    return (
        <GuideViewer 
            document={selectedGuide} 
            fichaNumber={FICHA_NUMBER_DISPLAY}
            apprentice={apprentice}
            onBack={() => setSelectedGuide(null)} 
            onSubmit={onSaveSubmission}
            initialSubmission={existingSubmission}
            isInstructorMode={isInstructorMode} // Pass down to viewer
        />
    );
  }

  const getDocumentsByType = (type: DocumentType) => {
    return documents.filter(doc => doc.type === type);
  };

  const getSubmissionStatus = (docId: string) => {
      const sub = apprentice.submissions?.find(s => s.guideId === docId);
      return sub ? sub.status : null;
  };

  const renderDocumentList = (type: DocumentType, emptyMessage: string, icon: string, colorClass: string) => {
    const docs = getDocumentsByType(type);
    if (docs.length === 0) {
        return (
            <div className="bg-white rounded-3xl p-10 border border-slate-200 shadow-sm text-center">
                <div className={`size-20 ${colorClass.replace('text-', 'bg-').replace('600', '50')} rounded-full flex items-center justify-center mx-auto mb-6 ${colorClass}`}>
                <span className="material-symbols-outlined text-4xl">{icon}</span>
                </div>
                <h3 className="text-xl font-bold text-sena-dark mb-2">Sin Documentos</h3>
                <p className="text-slate-500 max-w-md mx-auto mb-8">{emptyMessage}</p>
            </div>
        );
    }

    return (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {docs.map(doc => {
                const status = getSubmissionStatus(doc.id);
                const isApproved = status === 'APPROVED';
                return (
                    <div key={doc.id} className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm hover:shadow-md transition-all group flex items-start gap-4">
                        <div className={`size-12 rounded-xl flex items-center justify-center text-white shrink-0 ${type === 'GUIA' ? 'bg-purple-500' : type === 'PTC' ? 'bg-sena-green' : 'bg-blue-500'}`}>
                            <span className="material-symbols-outlined">{icon}</span>
                        </div>
                        <div className="flex-1 min-w-0">
                            <h4 className="font-bold text-slate-800 text-sm truncate group-hover:text-sena-green transition-colors">{doc.title}</h4>
                            <p className="text-xs text-slate-400 mt-1">{doc.fileName}</p>
                            <div className="flex items-center justify-between mt-1">
                                <p className="text-[10px] text-slate-300">Subido: {doc.uploadDate}</p>
                                {status === 'SUBMITTED' && (
                                    <span className="text-[10px] font-bold text-orange-600 bg-orange-50 px-2 py-0.5 rounded-full flex items-center gap-1">
                                        <span className="material-symbols-outlined text-[10px]">pending</span> Pendiente
                                    </span>
                                )}
                                {status === 'APPROVED' && (
                                    <span className="text-[10px] font-bold text-green-600 bg-green-50 px-2 py-0.5 rounded-full flex items-center gap-1">
                                        <span className="material-symbols-outlined text-[10px]">check_circle</span> Aprobado
                                    </span>
                                )}
                            </div>
                        </div>
                        
                        <button 
                            onClick={() => setSelectedGuide(doc)}
                            className={`text-white px-3 py-1.5 rounded-lg text-xs font-bold transition-colors flex items-center gap-1 shadow-sm ${type === 'GUIA' ? 'bg-sena-green hover:bg-[#2e8600]' : 'bg-slate-700 hover:bg-slate-900'}`}
                        >
                            <span>{status ? 'Ver' : 'Abrir'}</span>
                            <span className="material-symbols-outlined text-sm">{status ? 'visibility' : 'open_in_new'}</span>
                        </button>
                    </div>
                );
            })}
        </div>
    );
  };

  return (
    <div className="bg-[#f4f7f5] text-slate-900 min-h-screen font-sans">
      <nav className={`border-b border-slate-200 h-16 sticky top-0 z-50 ${isInstructorMode ? 'bg-sena-dark text-white' : 'bg-white'}`}>
        <div className="max-w-7xl mx-auto px-4 h-full flex items-center justify-between">
          <div className="flex items-center gap-3">
             {isInstructorMode && (
                 <button onClick={onBack} className="mr-2 text-white/70 hover:text-white">
                     <span className="material-symbols-outlined">arrow_back</span>
                 </button>
             )}
             {/* Logo logic */}
             <div className={`size-10 ${isInstructorMode ? 'bg-white text-sena-dark' : 'bg-sena-green text-white'} flex items-center justify-center rounded-lg`}>
              <span className="material-symbols-outlined font-bold">school</span>
            </div>
            <div>
              <h1 className={`text-xl font-extrabold tracking-tight ${isInstructorMode ? 'text-white' : 'text-sena-dark'}`}>SENA</h1>
              <p className={`text-[10px] font-bold uppercase tracking-widest leading-none ${isInstructorMode ? 'text-white/60' : 'text-slate-400'}`}>
                  {isInstructorMode ? 'Revisión de Instructor' : 'Seguimiento de Aprendiz'}
              </p>
            </div>
          </div>
          
          <div className="flex items-center gap-6">
            <div className={`hidden md:flex items-center gap-2 text-sm font-medium ${isInstructorMode ? 'text-white/80' : 'text-slate-600'}`}>
              <span className={`material-symbols-outlined ${isInstructorMode ? 'text-sena-green' : 'text-sena-green'}`}>verified_user</span>
              Ficha: {FICHA_NUMBER_DISPLAY} - ADSO
            </div>
            <div className={`flex items-center gap-3 pl-6 border-l ${isInstructorMode ? 'border-white/20' : 'border-slate-200'}`}>
              <div className="text-right">
                <p className={`text-sm font-bold ${isInstructorMode ? 'text-white' : 'text-slate-900'}`}>{apprentice.fullName.toUpperCase()}</p>
                <p className={`text-[10px] font-bold uppercase ${isInstructorMode ? 'text-sena-green' : 'text-sena-green'}`}>Estado: {apprentice.status}</p>
              </div>
              {apprentice.photoUrl ? (
                <div 
                  className="size-10 rounded-full bg-slate-200 bg-cover bg-center border-2 border-sena-green/20" 
                  style={{ backgroundImage: `url('${apprentice.photoUrl}')` }}
                ></div>
              ) : (
                <div className="size-10 rounded-full bg-sena-green/10 flex items-center justify-center text-sena-green font-bold border-2 border-sena-green/20">
                  {apprentice.initials}
                </div>
              )}
              {!isInstructorMode && (
                <button onClick={onBack} className="text-slate-400 hover:text-red-500 transition-colors">
                    <span className="material-symbols-outlined">logout</span>
                </button>
              )}
            </div>
          </div>
        </div>
      </nav>

      <main className="max-w-7xl mx-auto px-4 py-8">
         {/* ... (Existing Main Content) ... */}
        <div className="grid grid-cols-12 gap-8">
          {/* Left Column */}
          <div className="col-span-12 lg:col-span-4 space-y-6">
            <div className="bg-white rounded-3xl p-8 shadow-sm border border-slate-100 flex flex-col items-center text-center">
              <h3 className="text-lg font-bold text-sena-dark mb-6">Avance de Formación</h3>
              <div className="relative size-48 flex items-center justify-center circular-progress rounded-full mb-6" style={{ background: `radial-gradient(closest-side, white 79%, transparent 80% 100%), conic-gradient(#39a900 ${apprentice.progressPercentage}%, #e2e8f0 0)` }}>
                <div className="text-center">
                  <span className="text-5xl font-black text-sena-dark">{apprentice.progressPercentage}%</span>
                  <p className="text-xs font-bold text-slate-400 uppercase">Completado</p>
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4 w-full">
                <div className="bg-slate-50 p-3 rounded-2xl">
                  <p className="text-[10px] font-bold text-slate-400 uppercase mb-1">Aprobados</p>
                  <p className="text-xl font-bold text-sena-green">{apprentice.approvedCompetencies} RAP</p>
                </div>
                <div className="bg-slate-50 p-3 rounded-2xl">
                  <p className="text-[10px] font-bold text-slate-400 uppercase mb-1">Pendientes</p>
                  <p className="text-xl font-bold text-slate-400">{apprentice.totalCompetencies - apprentice.approvedCompetencies} RAP</p>
                </div>
              </div>
              <p className="mt-6 text-sm text-slate-500 italic">"El éxito es la suma de pequeños esfuerzos repetidos día tras día."</p>
            </div>
            
            <div className="bg-white rounded-3xl p-6 shadow-sm border border-slate-100">
               <h3 className="text-sm font-bold text-slate-800 mb-4 uppercase flex items-center gap-2">
                 <span className="material-symbols-outlined text-sena-green">notifications</span>
                 Novedades
               </h3>
               <div className="space-y-4">
                  {announcements.length === 0 && (
                      <p className="text-xs text-slate-400 text-center py-4">No hay novedades recientes.</p>
                  )}
                  {announcements.map(ann => (
                      <div key={ann.id} className={`flex gap-3 items-start p-3 rounded-xl border ${ann.type === 'INFO' ? 'bg-blue-50 border-blue-100' : 'bg-orange-50 border-orange-100'}`}>
                        <span className={`material-symbols-outlined text-sm mt-0.5 ${ann.type === 'INFO' ? 'text-blue-500' : 'text-orange-500'}`}>
                            {ann.type === 'INFO' ? 'info' : 'warning'}
                        </span>
                        <div>
                        <p className={`text-xs font-bold ${ann.type === 'INFO' ? 'text-blue-700' : 'text-orange-700'}`}>{ann.title}</p>
                        <p className={`text-[10px] mt-1 ${ann.type === 'INFO' ? 'text-blue-600/70' : 'text-orange-600/70'}`}>{ann.description}</p>
                        </div>
                    </div>
                  ))}
               </div>
            </div>
          </div>

          {/* Right Column */}
          <div className="col-span-12 lg:col-span-8">
             {/* Tabs Navigation */}
             <div className="flex items-center gap-2 mb-6 overflow-x-auto pb-2">
                <button 
                  onClick={() => setActiveTab('competencias')}
                  className={`px-5 py-2.5 rounded-full text-xs font-bold transition-all whitespace-nowrap ${activeTab === 'competencias' ? 'bg-sena-dark text-white shadow-lg shadow-sena-dark/20' : 'bg-white text-slate-500 hover:bg-slate-100'}`}
                >
                  Competencias
                </button>
                <button 
                  onClick={() => setActiveTab('guias')}
                  className={`px-5 py-2.5 rounded-full text-xs font-bold transition-all whitespace-nowrap ${activeTab === 'guias' ? 'bg-purple-600 text-white shadow-lg shadow-purple-600/20' : 'bg-white text-slate-500 hover:bg-slate-100'}`}
                >
                  Guías de Aprendizaje
                </button>
                <button 
                  onClick={() => setActiveTab('ptc')}
                  className={`px-5 py-2.5 rounded-full text-xs font-bold transition-all whitespace-nowrap ${activeTab === 'ptc' ? 'bg-sena-green text-white shadow-lg shadow-sena-green/20' : 'bg-white text-slate-500 hover:bg-slate-100'}`}
                >
                  Planes Concertados
                </button>
                <button 
                  onClick={() => setActiveTab('ldc')}
                  className={`px-5 py-2.5 rounded-full text-xs font-bold transition-all whitespace-nowrap ${activeTab === 'ldc' ? 'bg-blue-600 text-white shadow-lg shadow-blue-600/20' : 'bg-white text-slate-500 hover:bg-slate-100'}`}
                >
                  Listas de Chequeo
                </button>
             </div>

             {/* Tab Content */}
             <div className="animate-[fadeIn_0.3s_ease-out]">
                {activeTab === 'competencias' && (
                   <div className="space-y-4">
                      {competencies.map(comp => (
                        <CompetencyAccordion key={comp.id} competency={comp} />
                      ))}
                   </div>
                )}

                {activeTab === 'guias' && renderDocumentList('GUIA', 'No tienes guías de aprendizaje asignadas por el momento.', 'menu_book', 'text-purple-600')}

                {activeTab === 'ptc' && renderDocumentList('PTC', 'No hay planes concertados disponibles.', 'handshake', 'text-sena-green')}

                {activeTab === 'ldc' && renderDocumentList('LDC', 'No hay listas de chequeo asignadas.', 'checklist', 'text-blue-600')}
             </div>
          </div>
        </div>
      </main>
    </div>
  );
};
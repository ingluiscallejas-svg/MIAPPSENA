import React, { useState, useRef, DragEvent, ChangeEvent, useEffect } from 'react';
import { Sidebar } from './Sidebar';
import { Apprentice, Ficha, DocumentType, FichaDocument, GuideContent, EvaluationItem, GridContent, PTCContent, PTCRow, AttendanceRecord, Announcement, ChecklistContent, ChecklistItem } from '../../types';
import { MOCK_COMPETENCIES } from '../../constants';

interface InstructorViewProps {
  fichas: Ficha[];
  currentFicha: Ficha;
  onSelectFicha: (id: string) => void;
  onCreateFicha: (number: string, program: string) => void;
  onSelectApprentice: (apprentice: Apprentice, role: 'instructor' | 'apprentice') => void;
  onUpdateApprentices: (fichaId: string, list: Apprentice[]) => void;
  onAddDocument: (fichaId: string, doc: FichaDocument) => void;
  announcements: Announcement[];
  onAddAnnouncement: (a: Announcement) => void;
  onDeleteAnnouncement: (id: string) => void;
}

export const InstructorView: React.FC<InstructorViewProps> = ({ 
  fichas, 
  currentFicha, 
  onSelectFicha, 
  onCreateFicha, 
  onSelectApprentice, 
  onUpdateApprentices,
  onAddDocument,
  announcements,
  onAddAnnouncement,
  onDeleteAnnouncement
}) => {
  const [currentSection, setCurrentSection] = useState<'dashboard' | 'upload' | 'tracking'>('dashboard');
  const [activeTab, setActiveTab] = useState<'aprendices' | 'documentos'>('aprendices');
  const [filter, setFilter] = useState<'Todos' | 'En formación' | 'Retirados'>('Todos');
  const [isDragActive, setIsDragActive] = useState(false);
  const [isUploading, setIsUploading] = useState(false);
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);
  const [isNewsOpen, setIsNewsOpen] = useState(false); 
  
  // Document Upload State
  const [targetFichaId, setTargetFichaId] = useState(currentFicha.id);
  const [docTitle, setDocTitle] = useState('');
  const [docType, setDocType] = useState<DocumentType>('GUIA');
  const [docGuideNumber, setDocGuideNumber] = useState('');
  const [selectedFile, setSelectedFile] = useState<File | null>(null);

  // Specific Guide Content State
  const [reflectionText, setReflectionText] = useState('');
  const [reflectionImage, setReflectionImage] = useState<string | null>(null);
  const [contextText, setContextText] = useState('');
  const [appropText, setAppropText] = useState('');
  const [transferText, setTransferText] = useState('');
  
  // Evaluation State
  const [evaluations, setEvaluations] = useState<EvaluationItem[]>([
      { id: '1', evidence: '', criteria: '', technique: '', instrument: '' }
  ]);

  // LDC (Checklist) Structured State
  const [ldcCompetencyId, setLdcCompetencyId] = useState('');
  const [ldcRapId, setLdcRapId] = useState('');
  const [ldcCriteria, setLdcCriteria] = useState('');
  const [ldcInstructor, setLdcInstructor] = useState('JUAN INSTRUCTOR');
  const [ldcEvidenceType, setLdcEvidenceType] = useState<'DESEMPENO' | 'PRODUCTO'>('PRODUCTO');
  const [ldcDescription, setLdcDescription] = useState('Se registra la evidencia descrita en la guía de aprendizaje');
  const [ldcItems, setLdcItems] = useState<ChecklistItem[]>([{ id: '1', text: '' }]);

  // PTC Specific State
  const [ptcProjectCode, setPtcProjectCode] = useState('');
  const [ptcPhase, setPtcPhase] = useState('');
  const [ptcInstructorName, setPtcInstructorName] = useState('');
  const [ptcRows, setPtcRows] = useState<PTCRow[]>([
    { id: '1', rap: '', activity: '', deliveryType: null, deliveryDate: '', delivered: null }
  ]);

  // ATTENDANCE STATE
  const [attendanceDate, setAttendanceDate] = useState(new Date().toISOString().split('T')[0]);
  const [currentAttendance, setCurrentAttendance] = useState<AttendanceRecord['records']>({});
  
  // Announcement State
  const [newAnnouncementTitle, setNewAnnouncementTitle] = useState('');
  const [newAnnouncementDesc, setNewAnnouncementDesc] = useState('');
  const [newAnnouncementType, setNewAnnouncementType] = useState<'INFO' | 'ALERT'>('INFO');

  // Modal State
  const [newFichaNumber, setNewFichaNumber] = useState('');
  const [newFichaProgram, setNewFichaProgram] = useState('');

  const fileInputRef = useRef<HTMLInputElement>(null);
  const reflectionImageInputRef = useRef<HTMLInputElement>(null);

  // Initialize attendance
  useEffect(() => {
    const initialRecords: AttendanceRecord['records'] = {};
    currentFicha.apprentices.forEach(app => {
        if (app.status === 'En formación') {
            initialRecords[app.id] = 'PRESENT'; 
        }
    });
    setCurrentAttendance(initialRecords);
  }, [currentFicha.id, attendanceDate]);


  const filteredApprentices = currentFicha.apprentices.filter(apprentice => {
    if (filter === 'Todos') return true;
    if (filter === 'En formación') return apprentice.status === 'En formación';
    if (filter === 'Retirados') return apprentice.status === 'Retirado';
    return true;
  });

  const handleDrag = (e: DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === 'dragenter' || e.type === 'dragover') {
      setIsDragActive(true);
    } else if (e.type === 'dragleave') {
      setIsDragActive(false);
    }
  };

  const processApprenticeFile = (file: File) => {
    if (!file) return;
    setIsUploading(true);
    setTimeout(() => {
       onUpdateApprentices(currentFicha.id, currentFicha.apprentices);
       setIsUploading(false);
       alert('Aprendices procesados.');
    }, 1000);
  };

  const handleReflectionImageUpload = (e: ChangeEvent<HTMLInputElement>) => {
      const file = e.target.files?.[0];
      if (file) {
          const reader = new FileReader();
          reader.onload = (ev) => {
              setReflectionImage(ev.target?.result as string);
          };
          reader.readAsDataURL(file);
      }
  };

  const handleEvaluationChange = (index: number, field: keyof EvaluationItem, value: string) => {
      const newEvaluations = [...evaluations];
      newEvaluations[index] = { ...newEvaluations[index], [field]: value };
      setEvaluations(newEvaluations);
  };

  const addEvaluationField = () => {
      setEvaluations([...evaluations, { 
          id: Date.now().toString(), 
          evidence: '', 
          criteria: '', 
          technique: '', 
          instrument: '' 
      }]);
  };

  const removeEvaluationField = (index: number) => {
      if (evaluations.length > 1) {
          const newEvaluations = evaluations.filter((_, i) => i !== index);
          setEvaluations(newEvaluations);
      }
  };

  // LDC Handlers
  const handleLdcItemChange = (index: number, text: string) => {
      const newItems = [...ldcItems];
      newItems[index] = { ...newItems[index], text };
      setLdcItems(newItems);
  };

  const addLdcItem = () => {
      setLdcItems([...ldcItems, { id: Date.now().toString(), text: '' }]);
  };

  const removeLdcItem = (index: number) => {
      if (ldcItems.length > 1) {
          setLdcItems(ldcItems.filter((_, i) => i !== index));
      }
  };

  // PTC Handlers
  const handlePtcRowChange = (index: number, field: keyof PTCRow, value: any) => {
    const newRows = [...ptcRows];
    newRows[index] = { ...newRows[index], [field]: value };
    setPtcRows(newRows);
  };

  const addPtcRow = () => {
    setPtcRows([...ptcRows, { id: Date.now().toString(), rap: '', activity: '', deliveryType: null, deliveryDate: '', delivered: null }]);
  };

  const removePtcRow = (index: number) => {
    if (ptcRows.length > 1) {
      setPtcRows(ptcRows.filter((_, i) => i !== index));
    }
  };

  // Validation Logic
  const isFormValid = () => {
    if (!docTitle) return false;
    
    if (docType === 'GUIA') {
        return !!selectedFile;
    } else if (docType === 'PTC') {
        return !!(ptcProjectCode && ptcPhase && ptcInstructorName);
    } else {
        // LDC
        return !!(ldcCompetencyId && ldcRapId && ldcCriteria && ldcItems.length > 0);
    }
  };

  const handleDocumentUpload = (e: React.FormEvent) => {
    e.preventDefault();
    if (!isFormValid()) return;

    setIsUploading(true);
    setTimeout(() => {
        const finalTitle = docType === 'GUIA' && docGuideNumber 
          ? `Guía ${docGuideNumber}: ${docTitle}`
          : docTitle;

        const objectUrl = selectedFile ? URL.createObjectURL(selectedFile) : undefined;
        const finalFileName = selectedFile ? selectedFile.name : `${docType}_Digital_${new Date().getTime()}.pdf`;

        let guideContent: GuideContent | undefined;
        let checklistContent: ChecklistContent | undefined;
        let ptcContent: PTCContent | undefined;

        if (docType === 'GUIA') {
            guideContent = {
                reflection: reflectionText,
                reflectionImage: reflectionImage || undefined,
                contextualization: contextText,
                appropriation: appropText,
                transfer: transferText,
                evaluations: evaluations.filter(e => e.evidence.trim() !== '')
            };
        } else if (docType === 'PTC') {
            ptcContent = {
              date: new Date().toISOString().split('T')[0],
              projectCode: ptcProjectCode,
              phase: ptcPhase,
              instructorName: ptcInstructorName,
              rows: ptcRows,
            };
        } else {
            // LDC (Checklist)
            const comp = MOCK_COMPETENCIES.find(c => c.id === ldcCompetencyId);
            const rap = comp?.results.find(r => r.id === ldcRapId);

            checklistContent = {
                program: currentFicha.program,
                competency: comp ? `${comp.number} - ${comp.title}` : '',
                rap: rap ? `${rap.code}: ${rap.description}` : '',
                criteria: ldcCriteria,
                instructorName: ldcInstructor,
                evidenceType: ldcEvidenceType,
                activityDescription: ldcDescription,
                items: ldcItems.filter(i => i.text.trim() !== '')
            };
        }

        const newDoc: FichaDocument = {
            id: Date.now().toString(),
            title: finalTitle,
            type: docType,
            uploadDate: new Date().toISOString().split('T')[0],
            fileName: finalFileName,
            guideNumber: docType === 'GUIA' ? docGuideNumber : undefined,
            fileUrl: objectUrl,
            guideContent: guideContent,
            checklistContent: checklistContent,
            ptcContent: ptcContent
        };
        
        const targetId = currentSection === 'upload' ? targetFichaId : currentFicha.id;

        onAddDocument(targetId, newDoc);
        setIsUploading(false);
        
        // Reset form
        setDocTitle('');
        setDocGuideNumber('');
        setSelectedFile(null);
        setReflectionText('');
        setReflectionImage(null);
        setContextText('');
        setAppropText('');
        setTransferText('');
        setEvaluations([{ id: '1', evidence: '', criteria: '', technique: '', instrument: '' }]);
        // PTC Reset
        setPtcProjectCode('');
        setPtcPhase('');
        setPtcInstructorName('');
        setPtcRows([{ id: '1', rap: '', activity: '', deliveryType: null, deliveryDate: '', delivered: null }]);
        // LDC Reset
        setLdcCompetencyId('');
        setLdcRapId('');
        setLdcCriteria('');
        setLdcItems([{ id: '1', text: '' }]);
        
        alert('Documento publicado exitosamente a la ficha ' + currentFicha.number);
    }, 1000);
  };

  const handleDrop = (e: DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragActive(false);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      if (currentSection === 'dashboard' && activeTab === 'aprendices') {
        processApprenticeFile(e.dataTransfer.files[0]);
      } else {
        setSelectedFile(e.dataTransfer.files[0]);
      }
    }
  };

  const handleChange = (e: ChangeEvent<HTMLInputElement>) => {
    e.preventDefault();
    if (e.target.files && e.target.files[0]) {
        if (currentSection === 'dashboard' && activeTab === 'aprendices') {
            processApprenticeFile(e.target.files[0]);
        } else {
            setSelectedFile(e.target.files[0]);
        }
    }
  };

  const onButtonClick = () => {
    fileInputRef.current?.click();
  };

  const handleSubmitCreate = (e: React.FormEvent) => {
    e.preventDefault();
    if (newFichaNumber && newFichaProgram) {
      onCreateFicha(newFichaNumber, newFichaProgram);
      setNewFichaNumber('');
      setNewFichaProgram('');
      setIsCreateModalOpen(false);
    }
  };

  const handleAddAnnouncementClick = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newAnnouncementTitle || !newAnnouncementDesc) return;
    const newAnnouncement: Announcement = {
        id: Date.now().toString(),
        title: newAnnouncementTitle,
        description: newAnnouncementDesc,
        type: newAnnouncementType,
        date: new Date().toLocaleDateString()
    };
    onAddAnnouncement(newAnnouncement);
    setNewAnnouncementTitle('');
    setNewAnnouncementDesc('');
  };

  const handleSidebarNavigate = (section: 'dashboard' | 'upload' | 'tracking') => {
    setCurrentSection(section);
    if (section === 'upload') {
        setTargetFichaId(currentFicha.id); // Sync default
    }
  };
  
  const handleSidebarSelectFicha = (id: string) => {
      onSelectFicha(id);
      setCurrentSection('dashboard');
  };

  // ATTENDANCE LOGIC
  const toggleAttendance = (apprenticeId: string) => {
      setCurrentAttendance(prev => {
          const current = prev[apprenticeId];
          let next: 'PRESENT' | 'ABSENT' | 'EXCUSED' = 'PRESENT';
          if (current === 'PRESENT') next = 'ABSENT';
          else if (current === 'ABSENT') next = 'EXCUSED';
          else next = 'PRESENT';
          return { ...prev, [apprenticeId]: next };
      });
  };

  const getAttendanceStats = () => {
      const values = Object.values(currentAttendance);
      return {
          present: values.filter(v => v === 'PRESENT').length,
          absent: values.filter(v => v === 'ABSENT').length,
          excused: values.filter(v => v === 'EXCUSED').length,
          total: values.length
      };
  };

  // Helper for LDC RAPs based on selected competency
  const activeCompetency = MOCK_COMPETENCIES.find(c => c.id === ldcCompetencyId);

  return (
    <div className="flex h-screen overflow-hidden bg-slate-50">
      <Sidebar 
        fichas={fichas} 
        currentFichaId={currentFicha.id} 
        currentSection={currentSection}
        onSelectFicha={handleSidebarSelectFicha}
        onRequestCreateFicha={() => setIsCreateModalOpen(true)}
        onNavigate={handleSidebarNavigate}
      />
      <div className="flex-1 flex flex-col min-w-0 overflow-hidden relative">
        <header className="h-16 bg-white border-b border-slate-200 flex items-center justify-between px-8 shrink-0">
          <div className="flex items-center gap-2">
            <h1 className="text-lg font-bold text-slate-800 uppercase tracking-tight">
                {currentSection === 'upload' ? 'Centro de Carga de Datos' : currentSection === 'tracking' ? 'Seguimiento Etapa Práctica' : 'Panel del Instructor'}
            </h1>
            {currentSection === 'dashboard' && (
                <div className="flex flex-col items-start leading-none ml-2 border-l-2 border-slate-200 pl-3">
                    <span className="px-2 py-0.5 bg-sena-green/10 text-sena-green rounded text-[10px] font-black uppercase">FICHA {currentFicha.number}</span>
                    <span className="text-[10px] font-semibold text-slate-400 px-1 mt-0.5 truncate max-w-[200px]">{currentFicha.program}</span>
                </div>
            )}
          </div>
        </header>

        <main className="flex-1 overflow-y-auto p-8">
          <div className="max-w-6xl mx-auto space-y-6">
            
            {currentSection === 'upload' ? (
                // --- UPLOAD VIEW ---
                <div className="animate-[fadeIn_0.3s_ease-out]">
                    <div className="bg-white rounded-3xl border border-slate-200 shadow-xl overflow-hidden">
                        <div className="bg-sena-dark p-8 text-white">
                            <h2 className="text-2xl font-bold mb-2">Estructuración de Documentos</h2>
                            <p className="text-slate-300 text-sm">
                                {docType === 'GUIA' ? 'Generar guía interactiva.' : docType === 'PTC' ? 'Diligenciar Plan de Trabajo Concertado.' : 'Crear Lista de Chequeo.'}
                            </p>
                        </div>
                        <div className="p-8">
                            <form onSubmit={handleDocumentUpload} className="grid grid-cols-12 gap-8">
                                
                                {/* ... Left Column ... */}
                                <div className="col-span-12 md:col-span-4 space-y-6 border-r border-slate-100 pr-6">
                                    <div className="space-y-1">
                                        <label className="text-xs font-bold text-slate-700 uppercase">Seleccionar Ficha</label>
                                        <select 
                                            value={targetFichaId}
                                            onChange={(e) => setTargetFichaId(e.target.value)}
                                            className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-sena-green/50 font-medium text-sm text-slate-700"
                                        >
                                            {fichas.map(f => (
                                                <option key={f.id} value={f.id}>
                                                    Ficha {f.number} - {f.program}
                                                </option>
                                            ))}
                                        </select>
                                    </div>

                                    <div className="space-y-1">
                                        <label className="text-xs font-bold text-slate-700 uppercase">Tipo de Documento</label>
                                        <div className="grid grid-cols-2 gap-2">
                                            {(['GUIA', 'PTC', 'LDC'] as const).map(type => (
                                                <button
                                                    key={type}
                                                    type="button"
                                                    onClick={() => setDocType(type)}
                                                    className={`px-2 py-3 text-xs font-bold rounded-xl border-2 transition-all flex flex-col items-center justify-center gap-1 ${docType === type ? 'bg-sena-green/10 text-sena-green border-sena-green' : 'bg-white text-slate-400 border-slate-200 hover:border-slate-300'}`}
                                                >
                                                    <span className="material-symbols-outlined text-base">
                                                        {type === 'GUIA' ? 'menu_book' : type === 'PTC' ? 'handshake' : 'checklist'}
                                                    </span>
                                                    {type === 'GUIA' ? 'Guía' : type === 'PTC' ? 'PTC' : 'Lista Chequeo'}
                                                </button>
                                            ))}
                                        </div>
                                    </div>

                                    {docType === 'GUIA' && (
                                        <div className="space-y-1 animate-[fadeIn_0.2s_ease-out]">
                                            <label className="text-xs font-bold text-slate-700 uppercase">Número de Guía</label>
                                            <input 
                                                type="number" 
                                                value={docGuideNumber}
                                                onChange={(e) => setDocGuideNumber(e.target.value)}
                                                placeholder="#"
                                                className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-sena-green/50 font-medium text-sm"
                                            />
                                        </div>
                                    )}

                                    <div className="space-y-1">
                                        <label className="text-xs font-bold text-slate-700 uppercase">Título del Documento</label>
                                        <input 
                                            type="text" 
                                            value={docTitle}
                                            onChange={(e) => setDocTitle(e.target.value)}
                                            placeholder={docType === 'GUIA' ? "Ej. Guía SQL" : docType === 'PTC' ? "Ej. PTC Trimestre 1" : "Ej. Lista Chequeo 1"}
                                            className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-sena-green/50 font-medium text-sm"
                                            required
                                        />
                                    </div>

                                    <div className="space-y-1">
                                        <label className="text-xs font-bold text-slate-700 uppercase">Archivo Base (PDF)</label>
                                        <div 
                                            onClick={onButtonClick}
                                            className="border-2 border-dashed border-slate-300 rounded-xl p-4 flex flex-col items-center justify-center cursor-pointer hover:border-sena-green hover:bg-sena-green/5 transition-colors"
                                        >
                                            <input ref={fileInputRef} type="file" className="hidden" accept=".pdf,.doc,.docx" onChange={handleChange} />
                                            {selectedFile ? (
                                                <div className="text-center">
                                                    <span className="material-symbols-outlined text-sena-green text-2xl">description</span>
                                                    <p className="text-xs font-bold text-slate-800 truncate max-w-[150px]">{selectedFile.name}</p>
                                                </div>
                                            ) : (
                                                <div className="text-center text-slate-400">
                                                    <span className="material-symbols-outlined text-2xl">cloud_upload</span>
                                                    <p className="text-[10px] font-bold">
                                                        {docType === 'GUIA' ? 'Subir Guía (Requerido)' : 'Opcional si es digital'}
                                                    </p>
                                                </div>
                                            )}
                                        </div>
                                    </div>
                                </div>

                                {/* --- Right Column: Editors --- */}
                                <div className="col-span-12 md:col-span-8 space-y-8">
                                    {docType === 'GUIA' ? (
                                        // --- GUIA EDITOR ---
                                        <div className="animate-[fadeIn_0.3s_ease-out] space-y-8">
                                            <div className="bg-slate-50 p-4 rounded-xl border border-slate-200">
                                                <div className="flex items-center justify-between mb-2">
                                                    <label className="text-sm font-bold text-sena-dark">3.1 Actividades de Reflexión Inicial</label>
                                                    <button type="button" onClick={() => reflectionImageInputRef.current?.click()} className="text-[10px] bg-white border border-slate-300 px-2 py-1 rounded hover:bg-slate-100 flex items-center gap-1 text-slate-600 font-bold">
                                                        <span className="material-symbols-outlined text-sm">image</span>{reflectionImage ? 'Cambiar Imagen' : 'Agregar Imagen'}
                                                    </button>
                                                    <input ref={reflectionImageInputRef} type="file" accept="image/*" className="hidden" onChange={handleReflectionImageUpload} />
                                                </div>
                                                {reflectionImage && (
                                                    <div className="mb-3 w-32 h-32 relative group"><img src={reflectionImage} alt="Reflexion" className="w-full h-full object-cover rounded-lg border border-slate-300" /><button onClick={() => setReflectionImage(null)} type="button" className="absolute -top-2 -right-2 bg-red-500 text-white rounded-full p-0.5 shadow-sm"><span className="material-symbols-outlined text-sm">close</span></button></div>
                                                )}
                                                <textarea value={reflectionText} onChange={(e) => setReflectionText(e.target.value)} placeholder="Describa la actividad..." className="w-full p-3 text-xs border border-slate-300 rounded-lg h-24" />
                                            </div>
                                            <div className="bg-slate-50 p-4 rounded-xl border border-slate-200">
                                                <label className="block text-sm font-bold text-sena-dark mb-2">3.2 Actividades de Contextualización</label>
                                                <textarea value={contextText} onChange={(e) => setContextText(e.target.value)} className="w-full p-3 text-xs border border-slate-300 rounded-lg h-24" />
                                            </div>
                                            <div className="bg-slate-50 p-4 rounded-xl border border-slate-200">
                                                <label className="block text-sm font-bold text-sena-dark mb-2">3.3 Actividades de Apropiación</label>
                                                <textarea value={appropText} onChange={(e) => setAppropText(e.target.value)} className="w-full p-3 text-xs border border-slate-300 rounded-lg h-24" />
                                            </div>
                                            <div className="bg-slate-50 p-4 rounded-xl border border-slate-200">
                                                <label className="block text-sm font-bold text-sena-dark mb-2">3.4 Actividades de Transferencia</label>
                                                <textarea value={transferText} onChange={(e) => setTransferText(e.target.value)} className="w-full p-3 text-xs border border-slate-300 rounded-lg h-24" />
                                            </div>
                                            <div className="bg-slate-50 p-4 rounded-xl border border-slate-200">
                                                <div className="flex items-center justify-between mb-4">
                                                    <label className="text-sm font-bold text-sena-dark">4. Actividades de Evaluación</label>
                                                    <button type="button" onClick={addEvaluationField} className="text-[10px] text-sena-green font-bold hover:underline flex items-center gap-1"><span className="material-symbols-outlined text-sm">add_circle</span> Agregar Fila</button>
                                                </div>
                                                <div className="space-y-4">
                                                    {evaluations.map((item, idx) => (
                                                        <div key={item.id} className="bg-white p-4 rounded-lg border border-slate-200 shadow-sm relative group">
                                                            <div className="flex items-center gap-2 mb-2"><span className="bg-slate-100 text-slate-500 text-[10px] font-black px-2 py-0.5 rounded">ITEM {idx + 1}</span>{evaluations.length > 1 && (<button type="button" onClick={() => removeEvaluationField(idx)} className="ml-auto text-slate-300 hover:text-red-500"><span className="material-symbols-outlined text-lg">delete</span></button>)}</div>
                                                            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                                                                <div className="space-y-1"><label className="text-[10px] font-bold text-sena-dark uppercase">Evidencias</label><textarea value={item.evidence} onChange={(e) => handleEvaluationChange(idx, 'evidence', e.target.value)} className="w-full p-2 text-xs border border-slate-300 rounded h-24 resize-none" /></div>
                                                                <div className="space-y-1"><label className="text-[10px] font-bold text-sena-dark uppercase">Criterios</label><textarea value={item.criteria} onChange={(e) => handleEvaluationChange(idx, 'criteria', e.target.value)} className="w-full p-2 text-xs border border-slate-300 rounded h-24 resize-none" /></div>
                                                                <div className="space-y-2"><label className="text-[10px] font-bold text-sena-dark uppercase">Técnicas</label><div><input type="text" value={item.technique} onChange={(e) => handleEvaluationChange(idx, 'technique', e.target.value)} className="w-full p-2 text-xs border border-slate-300 rounded mb-2" /><input type="text" value={item.instrument} onChange={(e) => handleEvaluationChange(idx, 'instrument', e.target.value)} className="w-full p-2 text-xs border border-slate-300 rounded" /></div></div>
                                                            </div>
                                                        </div>
                                                    ))}
                                                </div>
                                            </div>
                                        </div>
                                    ) : docType === 'PTC' ? (
                                        // --- PTC EDITOR (Structured) ---
                                        <div className="animate-[fadeIn_0.3s_ease-out] space-y-6">
                                            <div className="bg-slate-50 p-6 rounded-xl border border-slate-200">
                                                <h3 className="text-lg font-bold text-sena-dark mb-4 border-b border-slate-200 pb-2">Información del Plan Concertado</h3>
                                                <div className="grid grid-cols-2 gap-4 mb-4">
                                                  <div>
                                                    <label className="text-[10px] font-bold text-slate-500 uppercase">Código del Proyecto</label>
                                                    <input type="text" value={ptcProjectCode} onChange={e => setPtcProjectCode(e.target.value)} className="w-full p-2 text-sm border border-slate-300 rounded" placeholder="Ej. 3191698" />
                                                  </div>
                                                  <div>
                                                    <label className="text-[10px] font-bold text-slate-500 uppercase">Fase</label>
                                                    <input type="text" value={ptcPhase} onChange={e => setPtcPhase(e.target.value)} className="w-full p-2 text-sm border border-slate-300 rounded" placeholder="Ej. Análisis" />
                                                  </div>
                                                  <div className="col-span-2">
                                                    <label className="text-[10px] font-bold text-slate-500 uppercase">Nombre Instructor Técnico</label>
                                                    <input type="text" value={ptcInstructorName} onChange={e => setPtcInstructorName(e.target.value)} className="w-full p-2 text-sm border border-slate-300 rounded" placeholder="Nombre completo" />
                                                  </div>
                                                </div>
                                                <h3 className="text-lg font-bold text-sena-dark mb-4 mt-8 border-b border-slate-200 pb-2 flex justify-between items-center">
                                                  <span>Actividades y Evidencias</span>
                                                  <button type="button" onClick={addPtcRow} className="text-xs bg-sena-green text-white px-3 py-1 rounded hover:bg-[#2e8600] flex items-center gap-1">
                                                    <span className="material-symbols-outlined text-sm">add</span> Fila
                                                  </button>
                                                </h3>
                                                <div className="space-y-4">
                                                  {ptcRows.map((row, idx) => (
                                                    <div key={row.id} className="bg-white p-4 rounded border border-slate-200 relative group">
                                                      <button type="button" onClick={() => removePtcRow(idx)} className="absolute top-2 right-2 text-slate-300 hover:text-red-500"><span className="material-symbols-outlined text-base">close</span></button>
                                                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                                        <div>
                                                          <label className="text-[10px] font-bold text-slate-400 uppercase">Resultado de Aprendizaje</label>
                                                          <textarea value={row.rap} onChange={e => handlePtcRowChange(idx, 'rap', e.target.value)} className="w-full p-2 text-xs border border-slate-300 rounded h-16" placeholder="RAP..." />
                                                        </div>
                                                        <div>
                                                          <label className="text-[10px] font-bold text-slate-400 uppercase">Actividad a Desarrollar</label>
                                                          <textarea value={row.activity} onChange={e => handlePtcRowChange(idx, 'activity', e.target.value)} className="w-full p-2 text-xs border border-slate-300 rounded h-16" placeholder="Actividad..." />
                                                        </div>
                                                        <div>
                                                          <label className="text-[10px] font-bold text-slate-400 uppercase">Forma de Entrega</label>
                                                          <select value={row.deliveryType || ''} onChange={e => handlePtcRowChange(idx, 'deliveryType', e.target.value)} className="w-full p-2 text-xs border border-slate-300 rounded">
                                                            <option value="">Seleccione...</option>
                                                            <option value="FISICA">Física</option>
                                                            <option value="DIGITAL">Digital</option>
                                                            <option value="AMBOS">Ambos</option>
                                                          </select>
                                                        </div>
                                                        <div>
                                                          <label className="text-[10px] font-bold text-slate-400 uppercase">Fecha Entrega</label>
                                                          <input type="date" value={row.deliveryDate} onChange={e => handlePtcRowChange(idx, 'deliveryDate', e.target.value)} className="w-full p-2 text-xs border border-slate-300 rounded" />
                                                        </div>
                                                      </div>
                                                    </div>
                                                  ))}
                                                </div>
                                            </div>
                                        </div>
                                    ) : (
                                        // --- LDC (LISTA DE CHEQUEO) EDITOR ---
                                        <div className="animate-[fadeIn_0.3s_ease-out] space-y-6">
                                            <div className="bg-slate-50 p-6 rounded-xl border border-slate-200">
                                                <h3 className="text-lg font-bold text-sena-dark mb-4 border-b border-slate-200 pb-2">I. Información General (Amarillo)</h3>
                                                <div className="grid grid-cols-1 gap-4 mb-4">
                                                    <div>
                                                        <label className="text-[10px] font-bold text-slate-500 uppercase">Competencia Asociada</label>
                                                        <select 
                                                            value={ldcCompetencyId} 
                                                            onChange={e => { setLdcCompetencyId(e.target.value); setLdcRapId(''); }}
                                                            className="w-full p-2 text-sm border border-slate-300 rounded"
                                                        >
                                                            <option value="">Seleccione una competencia...</option>
                                                            {MOCK_COMPETENCIES.map(c => (
                                                                <option key={c.id} value={c.id}>{c.number} - {c.title}</option>
                                                            ))}
                                                        </select>
                                                    </div>
                                                    <div>
                                                        <label className="text-[10px] font-bold text-slate-500 uppercase">Resultado de Aprendizaje (RAP)</label>
                                                        <select 
                                                            value={ldcRapId} 
                                                            onChange={e => setLdcRapId(e.target.value)}
                                                            className="w-full p-2 text-sm border border-slate-300 rounded"
                                                            disabled={!ldcCompetencyId}
                                                        >
                                                            <option value="">Seleccione un RAP...</option>
                                                            {activeCompetency?.results.map(r => (
                                                                <option key={r.id} value={r.id}>{r.code}: {r.description}</option>
                                                            ))}
                                                        </select>
                                                    </div>
                                                    <div>
                                                        <label className="text-[10px] font-bold text-slate-500 uppercase">Criterios de Evaluación</label>
                                                        <input 
                                                            type="text" 
                                                            value={ldcCriteria} 
                                                            onChange={e => setLdcCriteria(e.target.value)} 
                                                            className="w-full p-2 text-sm border border-slate-300 rounded" 
                                                            placeholder="Ingrese los criterios..." 
                                                        />
                                                    </div>
                                                </div>

                                                <h3 className="text-lg font-bold text-sena-dark mb-4 mt-6 border-b border-slate-200 pb-2">Información Específica (Verde)</h3>
                                                <div className="grid grid-cols-2 gap-4 mb-4">
                                                    <div className="col-span-2 md:col-span-1">
                                                        <label className="text-[10px] font-bold text-slate-500 uppercase">Nombre del Instructor</label>
                                                        <input type="text" value={ldcInstructor} onChange={e => setLdcInstructor(e.target.value)} className="w-full p-2 text-sm border border-slate-300 rounded" />
                                                    </div>
                                                    <div className="col-span-2 md:col-span-1">
                                                        <label className="text-[10px] font-bold text-slate-500 uppercase">Tipo de Evidencia</label>
                                                        <div className="flex gap-4 mt-2">
                                                            <label className="flex items-center gap-2 text-sm cursor-pointer">
                                                                <input type="radio" checked={ldcEvidenceType === 'DESEMPENO'} onChange={() => setLdcEvidenceType('DESEMPENO')} className="text-sena-green focus:ring-sena-green" />
                                                                Desempeño
                                                            </label>
                                                            <label className="flex items-center gap-2 text-sm cursor-pointer">
                                                                <input type="radio" checked={ldcEvidenceType === 'PRODUCTO'} onChange={() => setLdcEvidenceType('PRODUCTO')} className="text-sena-green focus:ring-sena-green" />
                                                                Producto
                                                            </label>
                                                        </div>
                                                    </div>
                                                </div>
                                                
                                                <h3 className="text-lg font-bold text-sena-dark mb-4 mt-6 border-b border-slate-200 pb-2">II. Evidencia para Evaluar</h3>
                                                <div className="mb-6">
                                                    <textarea 
                                                        value={ldcDescription}
                                                        onChange={e => setLdcDescription(e.target.value)}
                                                        className="w-full p-3 text-sm border border-slate-300 rounded-lg h-20"
                                                        placeholder="Descripción de la evidencia..."
                                                    />
                                                </div>

                                                <h3 className="text-lg font-bold text-sena-dark mb-4 border-b border-slate-200 pb-2 flex justify-between items-center">
                                                  <span>III. Items a Evaluar</span>
                                                  <button type="button" onClick={addLdcItem} className="text-xs bg-sena-green text-white px-3 py-1 rounded hover:bg-[#2e8600] flex items-center gap-1">
                                                    <span className="material-symbols-outlined text-sm">add</span> Item
                                                  </button>
                                                </h3>
                                                <div className="space-y-2">
                                                    {ldcItems.map((item, idx) => (
                                                        <div key={item.id} className="flex gap-2 items-center">
                                                            <span className="w-8 text-center font-bold text-slate-500">{idx + 1}</span>
                                                            <input 
                                                                type="text" 
                                                                value={item.text} 
                                                                onChange={e => handleLdcItemChange(idx, e.target.value)}
                                                                className="flex-1 p-2 text-sm border border-slate-300 rounded"
                                                                placeholder="Variable / Indicador..."
                                                            />
                                                            <button type="button" onClick={() => removeLdcItem(idx)} className="text-slate-300 hover:text-red-500">
                                                                <span className="material-symbols-outlined">close</span>
                                                            </button>
                                                        </div>
                                                    ))}
                                                </div>
                                            </div>
                                        </div>
                                    )}

                                    <div className="pt-4 flex justify-end">
                                        <button 
                                            type="submit" 
                                            disabled={!isFormValid() || isUploading}
                                            className="px-8 py-4 bg-sena-green text-white font-bold rounded-xl hover:bg-[#2e8600] transition-colors shadow-lg shadow-sena-green/20 disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-3 text-sm"
                                        >
                                            <span className="material-symbols-outlined">save</span>
                                            {isUploading ? 'Guardando...' : `Publicar ${docType === 'GUIA' ? 'Guía' : 'Documento'}`}
                                        </button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            ) : currentSection === 'tracking' ? (
                // ... (Tracking view omitted for brevity, unchanged) ...
                <div className="animate-[fadeIn_0.3s_ease-out]">
                    {/* ... Same content as before ... */}
                    <div className="bg-white rounded-3xl border border-slate-200 shadow-xl overflow-hidden min-h-[600px] flex flex-col">
                        <div className="bg-sena-dark p-6 text-white flex justify-between items-center">
                            <div>
                                <h2 className="text-2xl font-bold mb-1">Seguimiento Etapa Práctica</h2>
                                <p className="text-slate-300 text-sm">Plataforma Tecnoparque Nodo Cúcuta</p>
                            </div>
                        </div>
                        <div className="flex-1 bg-slate-100 relative">
                             <iframe src="https://www.tecnoparquenodocucuta.com/web/cedrum_productivas/instructor/programas_instructor.php?etapa=PRACTICA" className="w-full h-full min-h-[800px] border-0" title="Seguimiento Etapa Práctica" />
                        </div>
                    </div>
                </div>
            ) : (
                // --- DASHBOARD VIEW (Unchanged) ---
                <>
                 {/* --- SECCIÓN CRONOGRAMA Y ASISTENCIA (RESTAURADO) --- */}
                 <div className="grid grid-cols-12 gap-6 mb-8 animate-[fadeIn_0.2s_ease-out]">
                    {/* CRONOGRAMA */}
                    <div className="col-span-12 lg:col-span-8">
                        <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm h-full">
                             <div className="flex items-center justify-between mb-6">
                                <h3 className="font-bold text-sena-dark flex items-center gap-2">
                                    <span className="material-symbols-outlined text-sena-green">calendar_month</span>
                                    Cronograma de Formación
                                </h3>
                                <span className="text-xs font-bold text-slate-400 bg-slate-100 px-3 py-1 rounded-full">Semana Actual</span>
                             </div>
                             <div className="grid grid-cols-5 gap-4 text-center">
                                 {['Lunes', 'Martes', 'Miércoles', 'Jueves', 'Viernes'].map((day, i) => (
                                     <div key={day} className={`p-3 rounded-xl border ${i === 2 ? 'bg-sena-green/5 border-sena-green' : 'bg-slate-50 border-slate-100'}`}>
                                         <p className="text-[10px] uppercase font-bold text-slate-400 mb-2">{day}</p>
                                         <p className="text-xs font-bold text-slate-800">{i === 2 ? 'SQL Avanzado' : i === 4 ? 'Inglés' : 'Java Spring'}</p>
                                         <p className="text-[10px] text-slate-500 mt-1">14:00 - 18:00</p>
                                     </div>
                                 ))}
                             </div>
                        </div>
                    </div>

                    {/* ASISTENCIA RAPIDA */}
                    <div className="col-span-12 lg:col-span-4">
                        <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm h-full flex flex-col">
                            <div className="flex items-center justify-between mb-4">
                                <h3 className="font-bold text-sena-dark">Asistencia Hoy</h3>
                                <input type="date" value={attendanceDate} onChange={(e) => setAttendanceDate(e.target.value)} className="text-xs border-none bg-slate-100 rounded px-2 py-1 font-bold text-slate-600 outline-none" />
                            </div>
                            <div className="flex-1 overflow-y-auto pr-2 space-y-3 max-h-[200px] scrollbar-thin">
                                {currentFicha.apprentices.filter(a => a.status === 'En formación').map(app => (
                                    <div key={app.id} className="flex items-center justify-between p-2 hover:bg-slate-50 rounded-lg transition-colors">
                                        <div className="flex items-center gap-3">
                                             <div className={`size-8 rounded-full flex items-center justify-center text-[10px] font-bold text-white ${currentAttendance[app.id] === 'PRESENT' ? 'bg-sena-green' : currentAttendance[app.id] === 'ABSENT' ? 'bg-red-500' : 'bg-orange-400'}`}>
                                                 {app.initials}
                                             </div>
                                             <p className="text-xs font-bold text-slate-700 truncate max-w-[120px]">{app.fullName}</p>
                                        </div>
                                        <button onClick={() => toggleAttendance(app.id)} className="text-[10px] font-bold underline text-slate-400 hover:text-sena-dark">
                                            {currentAttendance[app.id] === 'PRESENT' ? 'Presente' : currentAttendance[app.id] === 'ABSENT' ? 'Ausente' : 'Excusa'}
                                        </button>
                                    </div>
                                ))}
                            </div>
                            <div className="mt-4 pt-4 border-t border-slate-100 flex justify-between text-[10px] font-bold text-slate-500 uppercase">
                                <span>Presentes: {getAttendanceStats().present}</span>
                                <span>Ausentes: {getAttendanceStats().absent}</span>
                            </div>
                        </div>
                    </div>
                </div>

                 <section className="mb-8 animate-[fadeIn_0.3s_ease-out]">
                    <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden group">
                        <div className="p-6 border-b border-slate-100 flex items-center justify-between">
                            <div>
                                <h3 className="text-lg font-bold text-slate-800">Carga Masiva de Aprendices</h3>
                            </div>
                        </div>
                        <div className="p-8">
                            <div 
                                onDragEnter={handleDrag} onDragLeave={handleDrag} onDragOver={handleDrag} onDrop={handleDrop} onClick={onButtonClick}
                                className={`border-2 border-dashed rounded-xl p-10 flex flex-col items-center justify-center transition-all cursor-pointer group relative overflow-hidden ${isDragActive ? 'border-sena-green bg-sena-green/5' : 'border-slate-200 bg-slate-50/50 hover:bg-sena-green/5 hover:border-sena-green/30'}`}
                            >
                                <input ref={fileInputRef} type="file" className="hidden" accept=".csv,.xlsx,.xls" onChange={handleChange} />
                                <div className={`size-16 bg-white rounded-full shadow-sm flex items-center justify-center mb-4 transition-transform ${isDragActive ? 'scale-110' : 'group-hover:scale-110'}`}>
                                    <span className="material-symbols-outlined text-sena-green text-3xl">cloud_upload</span>
                                </div>
                                <p className="text-sm font-bold text-slate-700">Arrastre su archivo CSV aquí</p>
                            </div>
                        </div>
                    </div>
                 </section>
                 <section className="mb-8 animate-[fadeIn_0.4s_ease-out]">
                    <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
                        <table className="w-full text-left border-collapse">
                            <thead>
                                <tr className="bg-white border-b border-slate-100">
                                    <th className="px-6 py-4 text-[10px] font-black text-slate-400 uppercase tracking-widest">Documento</th>
                                    <th className="px-6 py-4 text-[10px] font-black text-slate-400 uppercase tracking-widest">Nombre del Aprendiz</th>
                                    <th className="px-6 py-4 text-[10px] font-black text-slate-400 uppercase tracking-widest">Estado</th>
                                    <th className="px-6 py-4 text-[10px] font-black text-slate-400 uppercase tracking-widest text-right">Acciones</th>
                                </tr>
                            </thead>
                            <tbody className="divide-y divide-slate-100">
                                {filteredApprentices.map((student) => (
                                    <tr key={student.id} className="hover:bg-slate-50 transition-colors">
                                        <td className="px-6 py-5 align-middle"><span className="text-sm font-bold text-slate-700">{student.documentNumber}</span></td>
                                        <td className="px-6 py-5 align-middle"><span className="text-sm font-bold text-slate-800">{student.fullName}</span></td>
                                        <td className="px-6 py-5 align-middle"><span className="inline-flex items-center px-3 py-1 bg-green-100 text-green-700 text-xs font-bold rounded-full">{student.status}</span></td>
                                        <td className="px-6 py-5 align-middle text-right">
                                            <div className="flex items-center justify-end gap-2">
                                                <button 
                                                    onClick={() => onSelectApprentice(student, 'apprentice')} 
                                                    className="text-slate-400 hover:text-sena-green flex items-center gap-1 bg-white border border-slate-200 rounded-lg px-2 py-1 transition-colors"
                                                    title="Simular Aprendiz (Firmar/Llenar)"
                                                >
                                                    <span className="material-symbols-outlined text-sm">person</span>
                                                    <span className="text-[10px] font-bold">Simular</span>
                                                </button>
                                                <button 
                                                    onClick={() => onSelectApprentice(student, 'instructor')} 
                                                    className="text-slate-400 hover:text-sena-dark flex items-center gap-1 bg-white border border-slate-200 rounded-lg px-2 py-1 transition-colors"
                                                    title="Revisar como Instructor"
                                                >
                                                    <span className="material-symbols-outlined text-sm">visibility</span>
                                                    <span className="text-[10px] font-bold">Revisar</span>
                                                </button>
                                            </div>
                                        </td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </div>
                 </section>
                </>
             )}
            
          </div>
        </main>
        {isCreateModalOpen && (
            <div className="absolute inset-0 z-50 flex items-center justify-center bg-slate-900/50 backdrop-blur-sm p-4">
                <div className="bg-white rounded-2xl p-6 w-full max-w-md">
                    <h3 className="text-lg font-bold mb-4">Nueva Ficha</h3>
                    <input type="text" value={newFichaNumber} onChange={e => setNewFichaNumber(e.target.value)} placeholder="Número" className="w-full p-2 border rounded mb-2" />
                    <input type="text" value={newFichaProgram} onChange={e => setNewFichaProgram(e.target.value)} placeholder="Programa" className="w-full p-2 border rounded mb-4" />
                    <div className="flex gap-2">
                        <button onClick={() => setIsCreateModalOpen(false)} className="flex-1 p-2 border rounded">Cancelar</button>
                        <button onClick={handleSubmitCreate} className="flex-1 p-2 bg-sena-green text-white rounded">Crear</button>
                    </div>
                </div>
            </div>
        )}
      </div>
    </div>
  );
};
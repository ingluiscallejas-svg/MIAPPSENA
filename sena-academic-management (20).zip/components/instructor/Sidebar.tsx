import React from 'react';
import { Ficha } from '../../types';

interface SidebarProps {
  fichas: Ficha[];
  currentFichaId: string;
  currentSection: 'dashboard' | 'upload' | 'tracking'; // Added 'tracking'
  onSelectFicha: (id: string) => void;
  onRequestCreateFicha: () => void;
  onNavigate: (section: 'dashboard' | 'upload' | 'tracking') => void;
}

export const Sidebar: React.FC<SidebarProps> = ({ 
  fichas, 
  currentFichaId, 
  currentSection,
  onSelectFicha, 
  onRequestCreateFicha,
  onNavigate
}) => {
  return (
    <aside className="w-64 bg-white border-r border-slate-200 flex flex-col shrink-0 h-full">
      <div className="p-6 flex items-center gap-3">
        <div className="size-10 flex items-center justify-center bg-sena-green rounded-lg text-white">
          <span className="material-symbols-outlined font-bold">school</span>
        </div>
        <div>
          <h2 className="text-xl font-extrabold leading-tight tracking-tight text-sena-dark">SENA</h2>
          <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Gestión Académica</span>
        </div>
      </div>
      
      <div className="flex-1 overflow-y-auto">
        <nav className="px-4 space-y-1 mt-4">
          <button 
            onClick={() => onNavigate('dashboard')}
            className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg transition-colors text-left ${
              currentSection === 'dashboard' ? 'sidebar-active' : 'text-slate-600 hover:bg-slate-50'
            }`}
          >
            <span className="material-symbols-outlined">dashboard</span>
            <span className="text-sm font-medium">Dashboard</span>
          </button>
          
          <button 
            onClick={() => onNavigate('upload')}
            className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg transition-colors text-left ${
              currentSection === 'upload' ? 'sidebar-active' : 'text-slate-600 hover:bg-slate-50'
            }`}
          >
            <span className="material-symbols-outlined">upload_file</span>
            <span className="text-sm font-medium">Cargar Datos</span>
          </button>

          <button 
            onClick={() => onNavigate('tracking')}
            className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg transition-colors text-left ${
              currentSection === 'tracking' ? 'sidebar-active' : 'text-slate-600 hover:bg-slate-50'
            }`}
          >
            <span className="material-symbols-outlined">work_history</span>
            <span className="text-sm font-medium">Seguimiento</span>
          </button>
          
          <div className="pt-6 pb-2 px-4 flex items-center justify-between">
            <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Mis Fichas</p>
            <button 
              onClick={onRequestCreateFicha}
              className="text-sena-green hover:text-sena-dark transition-colors"
              title="Nueva Ficha"
            >
              <span className="material-symbols-outlined text-sm font-bold">add</span>
            </button>
          </div>
          
          <div className="space-y-1 mb-6">
            {fichas.map(ficha => (
              <button
                key={ficha.id}
                onClick={() => onSelectFicha(ficha.id)}
                className={`w-full flex items-center gap-3 px-4 py-2.5 rounded-lg transition-colors text-left group ${
                  currentFichaId === ficha.id && currentSection === 'dashboard'
                    ? 'bg-slate-100 text-sena-dark font-bold' 
                    : 'text-slate-500 hover:bg-slate-50 hover:text-slate-700'
                }`}
              >
                <span className={`material-symbols-outlined text-lg ${currentFichaId === ficha.id && currentSection === 'dashboard' ? 'text-sena-green' : 'text-slate-300 group-hover:text-slate-400'}`}>folder_shared</span>
                <div className="flex-1 min-w-0">
                  <p className="text-xs truncate">Ficha {ficha.number}</p>
                  <p className="text-[10px] truncate opacity-70">{ficha.program}</p>
                </div>
              </button>
            ))}
          </div>

          <div className="pt-2 pb-2 px-4 border-t border-slate-100">
            <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mt-4">Administración</p>
          </div>
          <button className="w-full flex items-center gap-3 px-4 py-3 rounded-lg text-slate-600 hover:bg-slate-50 transition-colors text-left">
            <span className="material-symbols-outlined">settings</span>
            <span className="text-sm font-medium">Configuración</span>
          </button>
        </nav>
      </div>

      <div className="p-4 border-t border-slate-100">
        <div className="flex items-center gap-3 p-2 bg-slate-50 rounded-xl">
          <div className="size-9 rounded-full bg-sena-dark flex items-center justify-center text-white text-xs font-bold">
            JI
          </div>
          <div className="flex-1 min-w-0">
            <p className="text-xs font-bold truncate">Juan Instructor</p>
            <p className="text-[10px] text-sena-green font-bold uppercase">Centro de Comercio</p>
          </div>
          <button className="text-slate-400 hover:text-red-500 transition-colors">
            <span className="material-symbols-outlined text-sm">logout</span>
          </button>
        </div>
      </div>
    </aside>
  );
};